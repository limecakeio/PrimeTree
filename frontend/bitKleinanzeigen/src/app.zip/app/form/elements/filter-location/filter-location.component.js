"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var forms_service_1 = require("../../forms.service");
var LocationFilter = (function () {
    function LocationFilter(formService) {
        this.formService = formService;
        this.locations = [
            "Mannheim",
            "Heidelberg",
            "Köln",
            "Nürnberg",
            "München",
            "Zug"
        ];
    }
    LocationFilter.prototype.triggerFilter = function (location) {
        console.log(location);
    };
    LocationFilter.prototype.ngOnChanges = function (simpleChanges) {
    };
    return LocationFilter;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], LocationFilter.prototype, "listItems", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], LocationFilter.prototype, "filterPropertyName", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], LocationFilter.prototype, "mutuallyExclusive", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], LocationFilter.prototype, "selectAllEnabled", void 0);
LocationFilter = __decorate([
    core_1.Component({
        selector: 'filter-location',
        templateUrl: './filter-location.component.html',
        styleUrls: ['./filter-location.component.css']
    }),
    __metadata("design:paramtypes", [forms_service_1.FormService])
], LocationFilter);
exports.LocationFilter = LocationFilter;
//# sourceMappingURL=filter-location.component.js.map