"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var forms_service_1 = require("../../forms.service");
var FilterMultiValueCheckboxComponent = (function () {
    function FilterMultiValueCheckboxComponent(formService) {
        this.formService = formService;
        this.filterChanged = new core_1.EventEmitter();
        this.filterValueChecked = false;
        this.model = this.formService.model;
    }
    FilterMultiValueCheckboxComponent.prototype.setFilterOnModel = function () {
        this.model[this.filterPropertyName] = this.filterPropertyValue;
        this.filterChanged.emit();
    };
    FilterMultiValueCheckboxComponent.prototype.removeFilterFromModel = function () {
        this.model[this.filterPropertyName] = '';
        this.filterChanged.emit();
    };
    FilterMultiValueCheckboxComponent.prototype.changeFilterValue = function (event) {
        if (this.filterValueChecked) {
            var found = false;
            for (var i = 0; i < this.model[this.filterPropertyName].length && !found; i++) {
                if (this.model[this.filterPropertyName][i] === this.filterPropertyValue) {
                    found = true;
                    this.model[this.filterPropertyName].splice(i, 1);
                }
            }
        }
        else {
            this.model[this.filterPropertyName].push(this.filterPropertyValue);
        }
        this.filterValueChecked = !this.filterValueChecked;
        this.filterChanged.emit();
    };
    FilterMultiValueCheckboxComponent.prototype.ngOnChanges = function (simpleChanges) {
        if (!simpleChanges.hasOwnProperty('filterPropertyName')
            ||
                !simpleChanges.hasOwnProperty('filterPropertyValue')) {
            throw new Error('No filter name set for FilterCheckboxComponent! Please add one as an input property.');
        }
    };
    return FilterMultiValueCheckboxComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterMultiValueCheckboxComponent.prototype, "filterPropertyName", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterMultiValueCheckboxComponent.prototype, "filterString", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterMultiValueCheckboxComponent.prototype, "filterPropertyValue", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], FilterMultiValueCheckboxComponent.prototype, "filterChanged", void 0);
FilterMultiValueCheckboxComponent = __decorate([
    core_1.Component({
        selector: 'form-element-filter-multi-value-checkbox',
        templateUrl: './filter-multi-value-checkbox.component.html',
        styleUrls: ['./filter-multi-value-checkbox.component.css']
    }),
    __metadata("design:paramtypes", [forms_service_1.FormService])
], FilterMultiValueCheckboxComponent);
exports.FilterMultiValueCheckboxComponent = FilterMultiValueCheckboxComponent;
//# sourceMappingURL=filter-multi-value-checkbox.component.js.map