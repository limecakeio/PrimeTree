"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var forms_service_1 = require("../../forms.service");
var FilterCheckboxComponent = (function () {
    function FilterCheckboxComponent(formService) {
        this.formService = formService;
        this.filterChanged = new core_1.EventEmitter();
        this.filterValueChecked = false;
        this.model = this.formService.model;
        if (typeof this.formService.data === 'undefined') {
            this.formService.data = {};
        }
        this.data = this.formService.data;
    }
    FilterCheckboxComponent.prototype.changeFilterValue = function (event) {
        // event.preventDefault();
        // event.stopPropagation();
        var checkboxStatus = this.filterValueChecked;
        console.log(this.filterPropertyValue, this.filterValueChecked, this.data[this.filterPropertyName + 'FilterCheckboxChecked'], checkboxStatus);
        if (this.filterValueChecked) {
            this.filterValueChecked = false;
            this.data[this.filterPropertyName + 'FilterCheckboxChecked'] = false;
            checkboxStatus = false;
        }
        else {
            if (this.data[this.filterPropertyName + 'FilterCheckboxChecked']) {
                checkboxStatus = false;
            }
            else {
                this.filterValueChecked = true;
                this.data[this.filterPropertyName + 'FilterCheckboxChecked'] = true;
                checkboxStatus = true;
            }
        }
        console.log(this.filterPropertyValue, this.filterValueChecked, this.data[this.filterPropertyName + 'FilterCheckboxChecked'], checkboxStatus);
        return !checkboxStatus;
    };
    FilterCheckboxComponent.prototype.ngOnChanges = function (simpleChanges) {
        if (!simpleChanges.hasOwnProperty('filterPropertyName')
            ||
                !simpleChanges.hasOwnProperty('filterPropertyValue')) {
            throw new Error('No filter name set for FilterCheckboxComponent! Please add one as an input property.');
        }
        if (typeof this.data[this.filterPropertyName + 'FilterCheckboxChecked'] === 'undefined') {
            this.data[this.filterPropertyName + 'FilterCheckboxChecked'] = false;
        }
    };
    return FilterCheckboxComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterCheckboxComponent.prototype, "filterPropertyName", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterCheckboxComponent.prototype, "filterString", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterCheckboxComponent.prototype, "filterPropertyValue", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], FilterCheckboxComponent.prototype, "filterChanged", void 0);
FilterCheckboxComponent = __decorate([
    core_1.Component({
        selector: 'form-element-filter-checkbox',
        templateUrl: './filter-checkbox.component.html',
        styleUrls: ['./filter-checkbox.component.css']
    }),
    __metadata("design:paramtypes", [forms_service_1.FormService])
], FilterCheckboxComponent);
exports.FilterCheckboxComponent = FilterCheckboxComponent;
//# sourceMappingURL=filter-checkbox.component.js.map