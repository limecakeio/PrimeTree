"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var forms_service_1 = require("../../forms.service");
var FilterRadioComponent = (function () {
    function FilterRadioComponent(formService) {
        this.formService = formService;
        this.filterChanged = new core_1.EventEmitter();
        this.filterValueChecked = false;
        this.model = this.formService.model;
    }
    FilterRadioComponent.prototype.setFilterOnModel = function () {
        this.model[this.filterPropertyName] = this.filterPropertyValue;
        this.filterChanged.emit();
    };
    FilterRadioComponent.prototype.removeFilterFromModel = function () {
        this.model[this.filterPropertyName] = '';
        this.filterChanged.emit();
    };
    FilterRadioComponent.prototype.changeFilterValue = function (event) {
        console.log(this.filterValueChecked, this.filterPropertyName, this.filterPropertyValue, this.filterString);
        event.preventDefault();
        if (this.filterValueChecked) {
            if (this.model[this.filterPropertyName] === this.filterPropertyValue) {
                this.model[this.filterPropertyName] = '';
                this.filterValueChecked = !this.filterValueChecked;
                this.filterChanged.emit();
            } // else is omitted because many checkboxes can share the same filter
        }
        else {
            this.filterValueChecked = !this.filterValueChecked;
        }
    };
    FilterRadioComponent.prototype.changeFilterValue2 = function (event) {
        event.preventDefault();
        if (this.filterValueChecked) {
            if (this.model[this.filterPropertyName] === this.filterPropertyValue) {
                this.model[this.filterPropertyName] = '';
                this.filterValueChecked = !this.filterValueChecked;
                this.filterChanged.emit();
            } // else is omitted because many checkboxes can share the same filter
        }
        else {
            if (this.model[this.filterPropertyName] === '') {
                this.model[this.filterPropertyName] = this.filterPropertyValue;
                this.filterValueChecked = !this.filterValueChecked;
                this.filterChanged.emit();
            }
        }
    };
    FilterRadioComponent.prototype.ngOnChanges = function (simpleChanges) {
        if (!simpleChanges.hasOwnProperty('filterPropertyName')
            ||
                !simpleChanges.hasOwnProperty('filterPropertyValue')) {
            throw new Error('No filter name set for FilterRadioComponent! Please add one as an input property.');
        }
    };
    return FilterRadioComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterRadioComponent.prototype, "filterPropertyName", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterRadioComponent.prototype, "filterString", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterRadioComponent.prototype, "filterPropertyValue", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], FilterRadioComponent.prototype, "filterChanged", void 0);
FilterRadioComponent = __decorate([
    core_1.Component({
        selector: 'form-element-filter-radio',
        templateUrl: './filter-radio.component.html',
        styleUrls: ['./filter-radio.component.css']
    }),
    __metadata("design:paramtypes", [forms_service_1.FormService])
], FilterRadioComponent);
exports.FilterRadioComponent = FilterRadioComponent;
//# sourceMappingURL=filter-radio.component.js.map