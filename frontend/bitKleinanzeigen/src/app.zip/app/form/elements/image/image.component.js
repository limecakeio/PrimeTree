"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var html2canvas = require("html2canvas"); // original 03062017
// import html2canvas from 'html2canvas';
var forms_service_1 = require("../../forms.service");
var ImageFormComponent = (function () {
    function ImageFormComponent(formService, domSanitizer) {
        this.formService = formService;
        this.domSanitizer = domSanitizer;
        this.imagesrc = '';
        this.data = this.formService.data;
        this.model = this.formService.model;
        this.form = this.formService.form;
        if (typeof this.model.image === 'undefined') {
            this.model.image = null;
        }
        if (typeof this.model.imageAsBase === 'undefined') {
            this.model.imageAsByteArray = null;
        }
        if (typeof this.data.imageAsFile === 'undefined') {
            this.data.imageAsFile = null;
        }
    }
    ImageFormComponent.prototype.addMulipleEventListener = function (element, eventstring, handle) {
        var events = eventstring.split(' ');
        events.forEach(function (event) {
            element.addEventListener(event, handle);
        });
    };
    ImageFormComponent.prototype.handleEvents = function () {
        var _this = this;
        this.div = document.querySelector('.image-box');
        if (!this.div) {
            return;
        }
        this.addMulipleEventListener(this.div, 'drag', function (event) {
            event.preventDefault();
            event.stopPropagation();
        });
        this.addMulipleEventListener(this.div, 'dragover dragenter', function (event) {
            event.preventDefault();
            event.stopPropagation();
            _this.div.classList.add('is-dragover');
        });
        this.addMulipleEventListener(this.div, 'dragleave dragend drop', function (event) {
            event.preventDefault();
            event.stopPropagation();
            _this.div.classList.remove('is-dragover');
        });
        /**User drops a file into the dropper*/
        this.addMulipleEventListener(this.div, 'drop', function (event) {
            console.log("DATA TRANSFER", event.dataTransfer);
            _this.preloadImage(event.dataTransfer.files[0]);
            // this.fileToBase(this.data.imageAsFile, (base : string) => {
            //   this.data.imageAsBase = base;
            //   this.data.imageAsByteArray = this.baseToByte(base);
            //   let file : File = this.byteToFile(this.data.imageAsByteArray);
            //   // let str : StreamReader = new StreamReader();
            //   this.imagesrc = 'data:image/jpeg;base64,' + this.data.imageAsByteArray;
            //
            // });
            // this.fileToByteArray(this.data.imageAsFile, (bytearray : Uint8Array) => {
            //   // let src : string = String.fromCharCode.apply(null, bytearray);
            //   this.data.imageAsByteArray = bytearray;
            //   let ele = document.querySelector('#file-input-image');
            //   ele.appendChild(this.decodeArrayBuffer(bytearray, () => {
            //
            //   }));
            // });
        });
        /**User clicks on the file-upload*/
        // this.addMulipleEventListener(this.div, 'click', (event : any) => {
        //   console.log("DATA TRANSFER", event);
        //   this.preloadImage(event.dataTransfer.files[0]);
        // });
    };
    ;
    /**Generates and presents an image file from the uploader*/
    ImageFormComponent.prototype.preloadImage = function (imageFile) {
        /** TODO Upload the image to the server for processing*/
        //Generate a unique, alphanumeric target name to avoid collisions
        var utn = ((+new Date) + Math.random() * 100).toString(32).replace(/\W/g, '');
        /** TODO Upload the image to the server*/
        //Track and display the progress of the upload
        /*GENERATE IMAGE PREVIEW*/
        var imageResult = new Image();
        var ImageComponent = this;
        imageResult.onload = function () {
            /*Set the images dimensions*/
            ImageComponent.imgWidth = imageResult.width;
            ImageComponent.imgHeight = imageResult.height;
            /*Hide the image upload*/
            var imageInputContainer = document.querySelector(".image-input-container");
            imageInputContainer.classList.remove("active");
            /*Show the image preview - HAVE TO DO THIS FIRST TO GRAB CONTAINER DIMENSIONS LATER*/
            var resultImageContainer = document.querySelector(".result-image-container");
            resultImageContainer.classList.add("active");
            ImageComponent.setImageContainerDimensions();
            /*Inject image into preview as a background image*/
            ImageComponent.imagePreviewContainer.style.backgroundImage = "url('" + imageResult.src + "')";
            ImageComponent.setDimensionsAndZoomer();
        };
        imageResult.src = URL.createObjectURL(imageFile);
    };
    ImageFormComponent.prototype.zoomImage = function () {
        var rangeSlider = document.querySelector("#zoom-range");
        var imageContainer = document.querySelector("#file-input-image");
        //Adapt zoom-level to image-container background-image
        imageContainer.style.backgroundSize = "auto " + rangeSlider.value + "px";
    };
    /**Calculates the best position for an image to be displayed within the cropper
    and sets the zommer function accordingly*/
    ImageFormComponent.prototype.setDimensionsAndZoomer = function () {
        /**Calculate and set initial display size*/
        var imgRatio = this.imgHeight / this.imgWidth;
        var zoomRange = document.querySelector("#zoom-range");
        /*Get the image's as well as its container's dimensions
        to calculate the perfect initial display*/
        var ipcWidth = this.imagePreviewContainer.clientWidth;
        var ipcHeight = this.imagePreviewContainer.clientHeight;
        if (this.isLandscape()) {
            /*Center the image position for lanscape images*/
            this.imagePreviewContainer.style.backgroundPosition = "0px 0px";
            if (ipcWidth * imgRatio < ipcHeight) {
                this.imagePreviewContainer.style.backgroundSize = "auto " + ipcHeight + "px";
                zoomRange.min = ipcHeight + "";
                zoomRange.max = this.imgHeight + "";
                zoomRange.value = ipcHeight + "";
            }
            else {
                this.imagePreviewContainer.style.backgroundSize = "auto " + (ipcWidth * imgRatio) + "px";
                zoomRange.min = ipcWidth * imgRatio + "";
                zoomRange.max = this.imgWidth + "";
                zoomRange.value = ipcWidth * imgRatio + "";
            }
        }
        else {
            /*Center the image position for profile/square images*/
            this.imagePreviewContainer.style.backgroundPosition = ipcWidth / 2 - this.imgWidth / 4 + "px 0px";
            this.imagePreviewContainer.style.backgroundSize = "auto " + ipcHeight + "px";
            zoomRange.min = "0";
            zoomRange.max = this.imgHeight + "";
            zoomRange.value = ipcHeight + "";
        }
    };
    /**Returns true if the current image's orientation is landscape*/
    ImageFormComponent.prototype.isLandscape = function () {
        if (this.imgWidth > this.imgHeight) {
            return true;
        }
        return false;
    };
    /**Sets the image container to the OpenGraph dimension of 1:0.525*/
    ImageFormComponent.prototype.setImageContainerDimensions = function () {
        var resultImageContainer = document.querySelector(".result-image-container");
        resultImageContainer.style.height = resultImageContainer.clientWidth * 0.525 + "px";
    };
    /**Moves an image into the direction as provided by the String parameter up, down, left or right*/
    ImageFormComponent.prototype.moveImage = function (direction) {
        var imagePreviewContainer = document.querySelector("#file-input-image");
        var currentXpos = parseFloat(imagePreviewContainer.style.backgroundPositionX);
        var currentYpos = parseFloat(imagePreviewContainer.style.backgroundPositionY);
        var moveBy = 20;
        if (direction === 'up') {
            imagePreviewContainer.style.backgroundPositionY = currentYpos - moveBy + "px";
        }
        else if (direction === 'down') {
            imagePreviewContainer.style.backgroundPositionY = currentYpos + moveBy + "px";
        }
        else if (direction === 'left') {
            imagePreviewContainer.style.backgroundPositionX = currentXpos - moveBy + "px";
        }
        else if (direction === 'right') {
            imagePreviewContainer.style.backgroundPositionX = currentXpos + moveBy + "px";
        }
    };
    /**Resets the image container's contents to their initial state*/
    ImageFormComponent.prototype.resetImagePosition = function () {
        this.setDimensionsAndZoomer();
    };
    /**Resets the image upload, displaying only the upload form*/
    ImageFormComponent.prototype.removeImage = function () {
        var imagePreviewContainer = document.querySelector(".result-image-container");
        var imagePreview = document.querySelector("#file-input-image");
        //Reset the image
        imagePreview.innerHTML = "";
        //Hide the image preview
        imagePreviewContainer.classList.remove("active");
        //Show the image dropper
        document.querySelector(".image-input-container").classList.add("active");
    };
    ImageFormComponent.prototype.captureImage = function () {
        /*Hide the crop container*/
        var cropper = document.querySelector("#crop-container");
        cropper.style.display = "none";
        var test = document.querySelector("#test-image");
        html2canvas(test).then(function (canvas) {
            window.open(canvas.toDataURL("image/png"));
        });
    };
    ImageFormComponent.prototype.input = function (event) {
        var _this = this;
        this.data.imageAsFile = event.target.files[0];
        this.preloadImage(event.target.files[0]);
        var path = URL.createObjectURL(this.data.imageAsFile);
        var reader = new FileReader();
        reader.onloadend = function () {
            _this.image = _this.domSanitizer.bypassSecurityTrustStyle('url(' + reader.result + ')');
        };
        reader.readAsDataURL(this.data.imageAsFile);
        console.log(this.data.imageAsFile, path);
        // this.image = this.domSanitizer.bypassSecurityTrustStyle('url(' + path + ')');
    };
    // http://stackoverflow.com/questions/4564119/javascript-convert-byte-to-image
    ImageFormComponent.prototype.decodeArrayBuffer = function (buffer, onLoad) {
        var mime;
        // var a = new Uint8Array(buffer);
        var a = buffer;
        var nb = a.length;
        if (nb < 4)
            return null;
        var b0 = a[0];
        var b1 = a[1];
        var b2 = a[2];
        var b3 = a[3];
        if (b0 == 0x89 && b1 == 0x50 && b2 == 0x4E && b3 == 0x47)
            mime = 'image/png';
        else if (b0 == 0xff && b1 == 0xd8)
            mime = 'image/jpeg';
        else if (b0 == 0x47 && b1 == 0x49 && b2 == 0x46)
            mime = 'image/gif';
        else
            return null;
        var binary = "";
        for (var i = 0; i < nb; i++)
            binary += String.fromCharCode(a[i]);
        var base64 = window.btoa(binary);
        var image = new Image();
        image.onload = onLoad;
        image.src = 'data:' + mime + ';base64,' + base64;
        return image;
    };
    ImageFormComponent.prototype.submitImage = function (event) {
        var _this = this;
        if (event === null || event.target === null || event.target.files === null) {
            return;
        }
        var file = event.target.files[0];
        var reader = new FileReader();
        // reader.onload = this.readerOnload.bind(this);
        reader.readAsDataURL(file);
        reader.onloadend = function () {
            _this.model.imageAsByteArray = _this.baseToByte(reader.result);
        };
        // this.model.imageObj = file;
    };
    ImageFormComponent.prototype.fileToBase = function (file, callback) {
        var reader = new FileReader();
        // file.
        // console.log(file);
        reader.readAsDataURL(file);
        reader.onloadend = function () {
            callback(reader.result);
        };
    };
    ImageFormComponent.prototype.fileToByteArray = function (file, callback) {
        var reader = new FileReader();
        reader.readAsArrayBuffer(file);
        reader.onload = function () {
            callback(new Uint8Array(reader.result));
        };
    };
    ImageFormComponent.prototype.readerOnload = function (e) {
        var reader = e.target;
        this.imagesrc = reader.result;
        this.model.image = this.imagesrc;
    };
    ImageFormComponent.prototype.baseToByte = function (base) {
        // base = base.replace(/^data:image\/(png|jpg|jpeg);base64/‌​, '');
        // base = base.replace('data:image/','');
        // base = base.replace(/png|jpg|jpeg/, '');
        // base = base.replace(';base64,', '');
        base = base.replace(/^data:image\/(jpg|png|jpeg);base64,/, '');
        var byteCharacters = window.atob(base);
        var length = byteCharacters.length;
        var byteArray = new Uint8Array(new ArrayBuffer(length));
        for (var i = 0; i < length; i++) {
            byteArray[i] = byteCharacters.charCodeAt(i);
        }
        return byteArray;
    };
    ImageFormComponent.prototype.ngOnInit = function () {
        this.handleEvents();
    };
    ImageFormComponent.prototype.ngAfterViewInit = function () {
        this.imagePreviewContainer = document.querySelector("#file-input-image");
    };
    ImageFormComponent.prototype.byteToFile = function (byteArray) {
        var file = new File(byteArray, 'abcdef' + '.jpg', {
            type: 'image/jepg'
        });
        return file;
    };
    ImageFormComponent.prototype.byteToBase = function (byteArray) {
        var base = 'data:image/jpeg;base64,';
        var binary = '';
        var length = byteArray.length;
        for (var i = 0; i < length; i++) {
            binary += String.fromCharCode(byteArray[i]);
        }
        return base + window.btoa(binary);
    };
    /**Handle events*/
    /**Listen to the window to adapt image container on changes*/
    ImageFormComponent.prototype.onResize = function (event) {
        this.setImageContainerDimensions();
        this.setDimensionsAndZoomer();
    };
    return ImageFormComponent;
}());
__decorate([
    core_1.HostListener('window:resize', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ImageFormComponent.prototype, "onResize", null);
ImageFormComponent = __decorate([
    core_1.Component({
        selector: 'form-element-image',
        templateUrl: './image.component.html',
        styleUrls: ['./image.component.css']
    }),
    __metadata("design:paramtypes", [forms_service_1.FormService,
        platform_browser_1.DomSanitizer])
], ImageFormComponent);
exports.ImageFormComponent = ImageFormComponent;
//# sourceMappingURL=image.component.js.map