"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var forms_service_1 = require("../../forms.service");
var FilterListComponent = (function () {
    function FilterListComponent(formService, elementRef) {
        this.formService = formService;
        this.elementRef = elementRef;
        /** Only one or no filter can be activated*/
        this.mutuallyExclusive = false;
        /** adds a select all filter at the end*/
        this.selectAll = false;
        this.filterChanged = new core_1.EventEmitter();
        this.filterList = [];
        this.mutuallyExclusiveItemSet = false;
        this.selectAllEnabled = false;
        this.model = this.formService.model;
    }
    FilterListComponent.prototype.triggerFilter = function (event) {
        // let filter : string = event.srcElement.innerHTML;
        if (this.mutuallyExclusive) {
            this.handleMutuallyExclusiveFilter(event.target || event.srcElement);
        }
        else {
            this.handleFilterWithMultipleValues(event.target || event.srcElement);
        }
        this.filterChanged.emit();
    };
    FilterListComponent.prototype.triggerAll = function () {
        var _this = this;
        var elements = this.elementRef.nativeElement.querySelectorAll("#element-list li");
        this.model[this.filterPropertyName] = [];
        elements.forEach(function (element) {
            if (element.dataset.id) {
                element.classList.add('active');
            }
        });
        this.filterList.forEach(function (filterListItem) {
            _this.model[_this.filterPropertyName].push(filterListItem.value);
        });
        this.filterChanged.emit();
    };
    FilterListComponent.prototype.handleFilterWithMultipleValues = function (element) {
        if (element.classList.contains('active')) {
            var found = false;
            for (var i = 0; i < this.model[this.filterPropertyName].length && !found; i++) {
                if (this.model[this.filterPropertyName][i] === this.getFilterValueFromFilterDisplayText(element.innerHTML)) {
                    found = true;
                    this.model[this.filterPropertyName].splice(i, 1);
                    element.classList.remove('active');
                }
            }
        }
        else {
            this.model[this.filterPropertyName].push(this.getFilterValueFromFilterDisplayText(element.innerHTML));
            element.classList.add('active');
        }
    };
    FilterListComponent.prototype.handleMutuallyExclusiveFilter = function (element) {
        if (element.classList.contains('active')) {
            this.model[this.filterPropertyName] = '';
            this.mutuallyExclusiveItemSet = false;
            element.classList.remove('active');
        }
        else {
            if (this.mutuallyExclusiveItemSet) {
                this.elementRef.nativeElement.querySelector('.active').classList.remove('active');
            }
            this.model[this.filterPropertyName] = this.getFilterValueFromFilterDisplayText(element.innerHTML);
            this.mutuallyExclusiveItemSet = true;
            element.classList.add('active');
        }
    };
    FilterListComponent.prototype.getFilterValueFromFilterDisplayText = function (name) {
        var found = false;
        var value;
        for (var i = 0; i < this.filterList.length && !found; i++) {
            if (this.filterList[i].displayText === name) {
                found = true;
                value = this.filterList[i].value;
            }
        }
        return value;
    };
    FilterListComponent.prototype.ngOnChanges = function (simpleChanges) {
        var _this = this;
        if (typeof simpleChanges['filterListItems']['currentValue'][0] === 'string') {
            simpleChanges['filterListItems']['currentValue'].forEach(function (filterName) {
                _this.filterList.push({
                    value: filterName,
                    displayText: filterName
                });
            });
        }
        else if (simpleChanges['filterListItems']['currentValue'][0].hasOwnProperty('value')) {
            simpleChanges['filterListItems']['currentValue'].forEach(function (filterItem) {
                _this.filterList.push({
                    value: filterItem.value,
                    displayText: filterItem.displayText || filterItem.value
                });
            });
        }
        if (typeof simpleChanges['selectAll'] === 'undefined') {
            return;
        }
        if (typeof simpleChanges['selectAll']['currentValue'] === 'boolean') {
            this.selectAllFilterListItem = {
                value: '',
                displayText: 'Select All'
            };
        }
        else if (typeof simpleChanges['selectAll']['currentValue'] === 'string') {
            this.selectAllFilterListItem = {
                value: simpleChanges['selectAll']['currentValue'],
                displayText: simpleChanges['selectAll']['currentValue']
            };
        }
        else if (simpleChanges['selectAll']['currentValue'].hasOwnProperty('value')) {
            this.selectAllFilterListItem = {
                value: simpleChanges['selectAll']['currentValue'].value,
                displayText: simpleChanges['selectAll']['currentValue'].displayText || simpleChanges['selectAll']['currentValue'].value
            };
        }
        this.selectAllEnabled = true;
    };
    return FilterListComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], FilterListComponent.prototype, "filterListItems", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], FilterListComponent.prototype, "filterPropertyName", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], FilterListComponent.prototype, "mutuallyExclusive", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], FilterListComponent.prototype, "selectAll", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], FilterListComponent.prototype, "filterChanged", void 0);
FilterListComponent = __decorate([
    core_1.Component({
        selector: 'filter-list',
        templateUrl: './filter-list.component.html',
        styleUrls: ['./filter-list.component.css']
    }),
    __metadata("design:paramtypes", [forms_service_1.FormService,
        core_1.ElementRef])
], FilterListComponent);
exports.FilterListComponent = FilterListComponent;
//# sourceMappingURL=filter-list.component.js.map