"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
require("rxjs/add/operator/map");
var network_service_1 = require("../../network/network.service");
var ListingsImageController = (function () {
    function ListingsImageController(networkService) {
        this.networkService = networkService;
    }
    ListingsImageController.prototype.listingMainImageUpload = function (listingId, file) {
        var formData = new FormData();
        formData.append('file', file);
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Put)
            .addPath('listing')
            .addPath('upload')
            .addPath('main-image')
            .addPath('' + listingId)
            .setBody(formData);
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User can only upload images to their own listings.');
            }
            else if (response.status === 404) {
                throw new Error(listingId + ' is no valid listing identifier.');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    ListingsImageController.prototype.galleryImageUpload = function (listingId, imageId, file) {
        var formData = new FormData();
        formData.append('file', file);
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Put)
            .addPath('listing')
            .addPath('upload')
            .addPath('gallery')
            .addPath('' + listingId)
            .addPath('' + imageId)
            .setBody(formData);
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 201) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User can only upload images to their own listings.');
            }
            else if (response.status === 404) {
                throw new Error('No valid identifier for listing or image.');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    ListingsImageController.prototype.removeGallery = function (listingId) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Delete)
            .addPath('listing')
            .addPath('upload')
            .addPath('gallery')
            .addPath('' + listingId);
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User can only remove the gallery of their own listings.');
            }
            else if (response.status === 404) {
                throw new Error('No valid identifier for listing.');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    return ListingsImageController;
}());
ListingsImageController = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [network_service_1.NetworkService])
], ListingsImageController);
exports.ListingsImageController = ListingsImageController;
//# sourceMappingURL=listings-image.controller.js.map