"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listing_repository_1 = require("./listing/listing.repository");
var listings_information_service_1 = require("./listings-information.service");
var ListingOverviewViewportComponent = (function () {
    function ListingOverviewViewportComponent(listingRepository, componentFactoryResolver, listingInformationService) {
        this.listingRepository = listingRepository;
        this.componentFactoryResolver = componentFactoryResolver;
        this.listingInformationService = listingInformationService;
        this.listingCounter = 0;
        this.listings = this.listingRepository.listings;
        this.listingDescriptorHandler = this.listingInformationService.listingDescriptorHandler;
    }
    ListingOverviewViewportComponent.prototype.findListingPreviewComponentTypeFromListingType = function (listingType) {
        return this.listingDescriptorHandler.findListingPreviewComponentTypeFromListingType(listingType);
    };
    ListingOverviewViewportComponent.prototype.getListings = function () {
        return this.listingRepository.listings;
    };
    /**Scrolls the displayed listings either forwards or backwards.
    Also calls to load more listings if user has scrolled to the end*/
    ListingOverviewViewportComponent.prototype.scrollListings = function (direction) {
        var scrollSpeed = 750;
        var finalScrollPosition;
        /**Determine how far to shift the container per click in any direction*/
        var listingWidth = document.querySelector(".listing").clientWidth;
        /*Define the scroll distance based on the device viewport size*/
        if (this.windowWidth < 480) {
            this.scrollOffset = listingWidth;
        }
        else {
            this.scrollOffset = listingWidth * 2;
        }
        /*Set the distance and direction*/
        var scrollDistance;
        if (direction === "forward") {
            scrollDistance = '+=' + this.scrollOffset;
        }
        else {
            scrollDistance = '-=' + this.scrollOffset;
        }
        /*Scroll the listings*/
        jQuery(this.listingScroller.nativeElement).animate({
            scrollLeft: scrollDistance
        }, scrollSpeed, function () {
            console.log("Load listings now!");
            /*If we have scrolled to the end we need to check for more listings*/
            var scrollPosition = this.setSliderControls();
            if (scrollPosition > this.listingWrapper.scrollWidth - this.listingWrapper.clientWidth - 100) {
                this.loadMoreListings();
            }
        }.bind(this));
    };
    ListingOverviewViewportComponent.prototype.loadMoreListings = function () {
        //Show user that we are working
        var loadScreen = document.querySelector("#listing-loader");
        loadScreen.classList.add("active");
        this.listingRepository.getNextListings();
        loadScreen.classList.remove("active");
        this.setViewport();
        // this.listingRepository.getNextListings();
        // loadScreen.classList.add("active");
        // this.listingRepository.getNextListings();
    };
    /**Sets the slider controls based on if they are required and returns the
    final scroll position as a number*/
    ListingOverviewViewportComponent.prototype.setSliderControls = function () {
        //Get the scroll position
        var scrollPosition = this.listingWrapper.scrollLeft;
        var scrollMax = this.listingWrapper.scrollWidth - this.listingWrapper.clientWidth;
        //Check if we even need to offer scroll
        if (scrollMax > 0) {
            //Grab the controls
            var backwardControl = document.querySelector("#viewport-control-backward");
            var forwardControl = document.querySelector("#viewport-control-forward");
            if (scrollPosition > 0) {
                backwardControl.classList.add("active");
            }
            else {
                backwardControl.classList.remove("active");
            }
            if (scrollPosition < scrollMax) {
                forwardControl.classList.add("active");
            }
            else {
                forwardControl.classList.remove("active");
            }
        }
        return this.listingWrapper.scrollLeft;
    };
    ListingOverviewViewportComponent.prototype.updateListingCounter = function () {
        this.listingCounter++;
        //Check when all the listings have been created and served before setting the viewport
        if (this.listingCounter === this.listingRepository.listingCount) {
            this.setViewport();
        }
    };
    ;
    /**Sets the listing viewport to achieve an optimal display across all devices*/
    ListingOverviewViewportComponent.prototype.setViewport = function () {
        console.log('setViewport');
        //Calculate the availble space for the viewport
        var headerHeight = document.querySelector("#header").clientHeight;
        var listingViewport = document.querySelector("#listing-viewport");
        var viewportHeight = this.windowHeight - headerHeight;
        listingViewport.style.height = viewportHeight + "px";
        /*Regardless of the device we are accessed from if a screen's height smaller
        than 650px we display the listings on a single line*/
        var viewPortMargin = 100; //Don't allow a listing to fill the entire container.
        var listings = document.querySelectorAll(".listing");
        var listingCubicSize;
        if (viewportHeight < 650) {
            //Display listings on a single row
            for (var i = 0; i < listings.length; i++) {
                listings[i].classList.add("single-row");
            }
            //Set the listing dimension
            listingCubicSize = viewportHeight - viewPortMargin;
        }
        else {
            //Display listings wihtin two rows
            for (var i = 0; i < listings.length; i++) {
                listings[i].classList.remove("single-row");
            }
            listingCubicSize = (viewportHeight / 2) - viewPortMargin;
        }
        //Apply the size to each listing and set its image-preview
        var listingPreviews = document.querySelectorAll(".listing-preview");
        for (var i = 0; i < listings.length; i++) {
            listingPreviews[i].style.width = listingCubicSize + "px";
            listingPreviews[i].style.height = listingCubicSize + "px";
            //Images to display in the OpenGraph ratio of 1:0.525
            listingPreviews[i].querySelector(".listing-image").style.height = listingCubicSize * 0.525 + "px";
        }
        this.setSliderControls();
    };
    ListingOverviewViewportComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        /*Set required window dimensions*/
        this.windowWidth = window.innerWidth;
        this.windowHeight = window.innerHeight;
        /*Set the listing container once component's been loaded*/
        this.listingWrapper = document.querySelector("#listing-wrapper");
        /**Set an event listener for when scroll occurs*/
        document.addEventListener('scroll', function (e) {
            /*If we have scrolled to the end we need to check for more listings*/
            var scrollPosition = _this.setSliderControls();
            if (scrollPosition > _this.listingWrapper.scrollWidth - _this.listingWrapper.clientWidth) {
                _this.loadMoreListings();
            }
        }, true);
    };
    ListingOverviewViewportComponent.prototype.onResize = function (event) {
        event.target.innerWidth;
        event.target.innerHeight;
        this.windowWidth = window.innerWidth;
        this.windowHeight = window.innerHeight;
        this.setViewport();
    };
    return ListingOverviewViewportComponent;
}());
__decorate([
    core_1.ViewChild('listingScroller'),
    __metadata("design:type", core_1.ElementRef)
], ListingOverviewViewportComponent.prototype, "listingScroller", void 0);
__decorate([
    core_1.HostListener('window:resize', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ListingOverviewViewportComponent.prototype, "onResize", null);
ListingOverviewViewportComponent = __decorate([
    core_1.Component({
        selector: 'listing-overview-viewport',
        templateUrl: './listing-overview-viewport.component.html',
        styleUrls: ['./listing-overview-viewport.component.css']
    }),
    __metadata("design:paramtypes", [listing_repository_1.ListingRepository,
        core_1.ComponentFactoryResolver,
        listings_information_service_1.ListingInformationService])
], ListingOverviewViewportComponent);
exports.ListingOverviewViewportComponent = ListingOverviewViewportComponent;
//# sourceMappingURL=listing-overview-viewport.component.js.map