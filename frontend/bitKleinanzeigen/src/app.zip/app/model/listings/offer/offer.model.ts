import { Listing } from '../listing/listing.model';

/**
 * all derived classes are offerings
 */
export abstract class Offer extends Listing {

}
