"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var service_offer_model_1 = require("./service-offer.model");
var listing_factory_1 = require("../../listing/listing.factory");
var ServiceOfferFactory = (function (_super) {
    __extends(ServiceOfferFactory, _super);
    function ServiceOfferFactory() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.vitalProperties = ['price'];
        return _this;
    }
    /**
     * checks if all neccesarily properties are set to convert the param object into a saleoffer object
     * @param {any} body an object which holds the properties
     * @return {boolean} indicates wheter the body has all properties
     */
    ServiceOfferFactory.prototype.checkProperties = function (body) {
        if (_super.prototype.checkProperties.call(this, body)) {
            for (var i = 0; i < this.vitalProperties.length; i++) {
                if (!body.hasOwnProperty(this.vitalProperties[i])) {
                    return false;
                }
            }
            return true;
        }
        return false;
    };
    ServiceOfferFactory.prototype.findMissingProperties = function (body) {
        var missingProperties = _super.prototype.findMissingProperties.call(this, body);
        this.vitalProperties.forEach(function (property) {
            missingProperties.push(property);
        });
        return missingProperties;
    };
    /**
     * creates a saleoffer based on the properties from the param object
     * @param {any} body an instance of object which holds all properties
     * @return {SaleOffer} a new instance of SaleOffer with all properties set accordingly to the body object
     * @throws {Error} an error if some properties are missing
     */
    ServiceOfferFactory.prototype.createListing = function (body) {
        if (this.checkProperties(body)) {
            var listing = new service_offer_model_1.ServiceOffer();
            this.assignProperties(listing, body);
            return listing;
        }
        else {
            throw new Error('Cannot create ServiceOffer from body: ' + this.findMissingProperties(body).join(', ') + ' are missing.');
        }
    };
    /**
     * Assigns all properties for a SaleOffer from body to listing.
     */
    ServiceOfferFactory.prototype.assignProperties = function (listing, body) {
        _super.prototype.assignProperties.call(this, listing, body);
        this.vitalProperties.forEach(function (property) {
            listing[property] = body[property];
        });
        if (body.hasOwnProperty('mainImage')) {
            listing.mainImage = body.mainImage;
        }
        if (body.hasOwnProperty('imageGallery')) {
            listing.imageGallery = body.imageGallery;
        }
    };
    return ServiceOfferFactory;
}(listing_factory_1.ListingFactory));
exports.ServiceOfferFactory = ServiceOfferFactory;
//# sourceMappingURL=service-offer.factory.js.map