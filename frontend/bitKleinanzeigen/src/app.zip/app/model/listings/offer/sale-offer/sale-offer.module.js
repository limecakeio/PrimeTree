"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var router_1 = require("@angular/router");
var sale_offer_component_1 = require("./sale-offer.component");
var sale_offer_preview_component_1 = require("./sale-offer-preview.component");
var sale_offer_create_form_component_1 = require("./sale-offer-create-form.component");
var form_module_1 = require("../../../../form/form.module");
var preview_module_1 = require("../../../../view/preview/preview.module");
var SaleOfferModule = (function () {
    function SaleOfferModule() {
    }
    return SaleOfferModule;
}());
SaleOfferModule = __decorate([
    core_1.NgModule({
        declarations: [
            sale_offer_component_1.SaleOfferComponent,
            sale_offer_preview_component_1.SaleOfferPreviewComponent,
            sale_offer_create_form_component_1.SaleOfferCreateFormComponent
        ],
        exports: [
            sale_offer_component_1.SaleOfferComponent,
            sale_offer_preview_component_1.SaleOfferPreviewComponent,
            sale_offer_create_form_component_1.SaleOfferCreateFormComponent,
            router_1.RouterModule,
            preview_module_1.PreviewModule
        ],
        imports: [
            common_1.CommonModule,
            form_module_1.FormModule,
            router_1.RouterModule,
            preview_module_1.PreviewModule
        ],
        providers: []
    })
], SaleOfferModule);
exports.SaleOfferModule = SaleOfferModule;
//# sourceMappingURL=sale-offer.module.js.map