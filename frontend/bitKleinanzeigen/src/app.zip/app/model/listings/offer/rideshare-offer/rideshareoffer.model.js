"use strict";
var RideShareOffer = (function () {
    function RideShareOffer() {
    }
    return RideShareOffer;
}());
exports.RideShareOffer = RideShareOffer;
//# sourceMappingURL=rideshareoffer.model.js.map