"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var offer_model_1 = require("../offer.model");
var SaleOffer = (function (_super) {
    __extends(SaleOffer, _super);
    function SaleOffer() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return SaleOffer;
}(offer_model_1.Offer));
exports.SaleOffer = SaleOffer;
//# sourceMappingURL=sale-offer.model.js.map