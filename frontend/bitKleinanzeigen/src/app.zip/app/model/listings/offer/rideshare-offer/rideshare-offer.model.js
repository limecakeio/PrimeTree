"use strict";
var RideShareOffer = (function () {
    function RideShareOffer() {
    }
    return RideShareOffer;
}());
exports.RideShareOffer = RideShareOffer;
//# sourceMappingURL=rideshare-offer.model.js.map