"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var listing_descriptor_1 = require("../../listing/listing.descriptor");
var sale_offer_preview_component_1 = require("./sale-offer-preview.component");
exports.SaleOfferPreviewComponent = sale_offer_preview_component_1.SaleOfferPreviewComponent;
var sale_offer_create_component_1 = require("./sale-offer-create.component");
exports.SaleOfferCreateFormComponent = sale_offer_create_component_1.SaleOfferCreateFormComponent;
var sale_offer_factory_1 = require("./sale-offer.factory");
var SaleOfferDescriptor = (function (_super) {
    __extends(SaleOfferDescriptor, _super);
    function SaleOfferDescriptor() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SaleOfferDescriptor.prototype.listingPreviewComponentType = function () {
        return sale_offer_preview_component_1.SaleOfferPreviewComponent;
    };
    SaleOfferDescriptor.prototype.listingType = function () {
        return 'SaleOffer';
    };
    SaleOfferDescriptor.prototype.listingCreateForm = function () {
        return sale_offer_create_component_1.SaleOfferCreateFormComponent;
    };
    SaleOfferDescriptor.prototype.listingFactory = function () {
        return new sale_offer_factory_1.SaleOfferFactory('SaleOffer');
    };
    return SaleOfferDescriptor;
}(listing_descriptor_1.ListingDescriptor));
exports.SaleOfferDescriptor = SaleOfferDescriptor;
//# sourceMappingURL=sale-offer.descriptor.js.map