"use strict";
var Reoccurence;
(function (Reoccurence) {
    Reoccurence[Reoccurence["Daily"] = 0] = "Daily";
    Reoccurence[Reoccurence["Weekly"] = 1] = "Weekly";
    Reoccurence[Reoccurence["Fortnightly"] = 2] = "Fortnightly";
    Reoccurence[Reoccurence["Monthly"] = 3] = "Monthly";
    Reoccurence[Reoccurence["Randomly"] = 4] = "Randomly";
})(Reoccurence = exports.Reoccurence || (exports.Reoccurence = {}));
//# sourceMappingURL=reoocurence.model.js.map