"use strict";
var Category;
(function (Category) {
    Category[Category["Sport"] = 0] = "Sport";
    Category[Category["Social"] = 1] = "Social";
    Category[Category["Outdoors"] = 2] = "Outdoors";
    Category[Category["Events"] = 3] = "Events";
})(Category = exports.Category || (exports.Category = {}));
//# sourceMappingURL=category.model.js.map