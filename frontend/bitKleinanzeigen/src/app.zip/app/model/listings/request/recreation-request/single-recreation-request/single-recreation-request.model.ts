import { RecreationRequest } from '../recreation-request.model';

export class SingleRecreationRequest {
  dateAndTime : Date;
}
