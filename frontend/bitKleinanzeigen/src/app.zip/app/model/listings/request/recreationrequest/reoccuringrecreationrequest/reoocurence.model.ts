export enum Reoccurence {
  Daily, Weekly, Fortnightly, Monthly, Randomly
}
