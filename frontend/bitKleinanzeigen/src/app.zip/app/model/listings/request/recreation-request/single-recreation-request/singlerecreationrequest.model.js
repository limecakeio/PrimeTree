"use strict";
var SingleRecreationRequest = (function () {
    function SingleRecreationRequest() {
    }
    return SingleRecreationRequest;
}());
exports.SingleRecreationRequest = SingleRecreationRequest;
//# sourceMappingURL=singlerecreationrequest.model.js.map