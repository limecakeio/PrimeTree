"use strict";
var SingleRecreationRequest = (function () {
    function SingleRecreationRequest() {
    }
    return SingleRecreationRequest;
}());
exports.SingleRecreationRequest = SingleRecreationRequest;
//# sourceMappingURL=single-recreation-request.model.js.map