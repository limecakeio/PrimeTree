"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var request_model_1 = require("../request.model");
var BorrowRequest = (function (_super) {
    __extends(BorrowRequest, _super);
    function BorrowRequest() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return BorrowRequest;
}(request_model_1.Request));
exports.BorrowRequest = BorrowRequest;
//# sourceMappingURL=borrow-request.model.js.map