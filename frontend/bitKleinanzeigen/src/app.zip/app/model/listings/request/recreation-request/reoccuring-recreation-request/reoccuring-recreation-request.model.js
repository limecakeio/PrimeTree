"use strict";
var ReoccuringRecreationRequest = (function () {
    function ReoccuringRecreationRequest() {
    }
    return ReoccuringRecreationRequest;
}());
exports.ReoccuringRecreationRequest = ReoccuringRecreationRequest;
//# sourceMappingURL=reoccuring-recreation-request.model.js.map