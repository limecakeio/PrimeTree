"use strict";
var ReoccuringRecreationRequest = (function () {
    function ReoccuringRecreationRequest() {
    }
    return ReoccuringRecreationRequest;
}());
exports.ReoccuringRecreationRequest = ReoccuringRecreationRequest;
//# sourceMappingURL=reoccuringrecreationrequest.model.js.map