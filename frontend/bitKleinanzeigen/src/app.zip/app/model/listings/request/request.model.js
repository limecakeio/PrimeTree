"use strict";
/**
 * all derived classes are request
 */
var Request = (function () {
    function Request() {
    }
    return Request;
}());
exports.Request = Request;
//# sourceMappingURL=request.model.js.map