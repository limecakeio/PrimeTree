"use strict";
var RecreationRequest = (function () {
    function RecreationRequest() {
    }
    return RecreationRequest;
}());
exports.RecreationRequest = RecreationRequest;
//# sourceMappingURL=recreationrequest.model.js.map