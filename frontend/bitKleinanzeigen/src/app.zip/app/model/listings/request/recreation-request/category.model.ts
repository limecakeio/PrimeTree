export enum Category {
  Sport, Social, Outdoors, Events
}
