import { Listing } from '../listing/listing.model';

/**
 * all derived classes are request
 */
export abstract class Request {

}
