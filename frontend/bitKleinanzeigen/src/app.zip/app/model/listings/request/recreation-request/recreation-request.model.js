"use strict";
var RecreationRequest = (function () {
    function RecreationRequest() {
    }
    return RecreationRequest;
}());
exports.RecreationRequest = RecreationRequest;
//# sourceMappingURL=recreation-request.model.js.map