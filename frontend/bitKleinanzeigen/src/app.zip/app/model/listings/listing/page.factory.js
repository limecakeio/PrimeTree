"use strict";
var page_model_1 = require("./page.model");
/**
 * This class builds a page from incoming JSON objects.
 */
var PageFactory = (function () {
    function PageFactory(listingCreator) {
        this.listingCreator = listingCreator;
        this.pageProperties = [
            'listings',
            'price_min',
            'price_max',
            'count',
            'pages',
            'pageNumber'
        ];
    }
    /**
     * Creates a page from the argument object which must contain all necessary properties for a page.
     * Throws an error if some or all properties are missing.
     * @argument {any} body
     * @return {Page}
     */
    PageFactory.prototype.createPage = function (body) {
        var _this = this;
        var page;
        if (this.checkPageProperties(body)) {
            page = new page_model_1.Page();
            page.count = body.count;
            page.listings = [];
            body.listings.forEach(function (element) {
                page.listings.push(_this.listingCreator.createListing(element));
            });
            page.pages = body.pages;
            page.price_max = body.price_max;
            page.price_min = body.price_min;
            page.pageNumber = body.pageNumber;
        }
        else {
            throw new Error('Cannot convert JSON object in a page, some or all properties are missing!');
        }
        return page;
    };
    /**
     *
     */
    PageFactory.prototype.checkPageProperties = function (body) {
        this.pageProperties.forEach(function (property) {
            if (!body.hasOwnProperty(property)) {
                return false;
            }
        });
        return true;
    };
    return PageFactory;
}());
exports.PageFactory = PageFactory;
//# sourceMappingURL=page.factory.js.map