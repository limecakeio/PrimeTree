"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
require("rxjs/add/operator/map");
var network_1 = require("../../../network/network");
var listing_request_1 = require("./listing.request");
var page_factory_1 = require("./page.factory");
var listing_creator_1 = require("./listing.creator");
var listing_list_1 = require("./listing.list");
var listings_information_service_1 = require("../listings-information.service");
/**
 * This class handles all network traffic which affects listings.
 */
var ListingController = (function () {
    function ListingController(networkService, listingInformationService) {
        this.networkService = networkService;
        this.listingInformationService = listingInformationService;
        this.listingCreator = new listing_creator_1.ListingCreator(this.listingInformationService);
        this.pageFactory = new page_factory_1.PageFactory(this.listingCreator);
        this.listingListFactory = new listing_list_1.ListingListFactory();
    }
    ListingController.prototype.loadNewPageSite = function (page) {
        var _this = this;
        var networkRequest = page.networkRequest;
        networkRequest.addQuery('page', page.pageNumber + '');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                var page_1 = _this.pageFactory.createPage(response.json());
                page_1.networkRequest = networkRequest;
                return page_1;
            }
            throw new Error(response.toString());
        });
    };
    /**
     * Returns a new ListingRequest which can be used with the get listings methods.
     * Hostname and port properties are already set accordingly to the NetworkService information.
     */
    ListingController.prototype.listingRequest = function () {
        return new listing_request_1.ListingRequest(this.networkService.networkRequest());
    };
    /**
     * Returns a Page which can be used to retrieve more pages.
     * @argument {ListingRequest} ListingRequest This object collects possible queries for this method.
     * @return {Observable<Page>} An observable which returns to a page or an error.
     */
    ListingController.prototype.getActiveListings = function (listingRequest) {
        var _this = this;
        var request;
        if (listingRequest === undefined) {
            request = this.networkService.networkRequest();
        }
        else {
            request = listingRequest.getRequest();
        }
        request
            .setHttpMethod(network_1.RequestMethod.Get)
            .addPath('listings')
            .addPath('active');
        return this.networkService.send(request).map(function (response) {
            if (response.status === 200) {
                var page = _this.pageFactory.createPage(response.json());
                page.networkRequest = request;
                return page;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    /**
     * Creates the listing on the server and returns the id of the created listing.
     * @argument {any} listing an object which holds all necessary properties to create the listing.
     */
    ListingController.prototype.createListing = function (listing) {
        var request = this.networkService.networkRequest();
        request
            .setHttpMethod(network_1.RequestMethod.Post)
            .addPath('listing')
            .addPath('create')
            .setBody(listing);
        return this.networkService.send(request).map(function (response) {
            if (response.status === 201) {
                return response.json().id;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    /**
     * Uploads the argument image to the server as the main image of the listing with the corresponding id.
     * @argument {number} listingId
     * @argument {File} image
     */
    ListingController.prototype.listingMainImageUpload = function (listingId, image) {
        var request = this.networkService.networkRequest();
        request
            .setHttpMethod(network_1.RequestMethod.Put)
            .addPath('listing')
            .addPath('upload')
            .addPath('main-image')
            .addPath('' + listingId);
        return this.networkService.send(request).map(function (response) {
            if (response.status === 201) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User must be the author of the corresponding listing to upload or change the main image!');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    /**
     * Removes the listing with the corresponding id on the server.
     * @argument {number} listingId
     * @return {Observable<void>}
     */
    ListingController.prototype.removeListing = function (listingId) {
        var request = this.networkService.networkRequest();
        request
            .setHttpMethod(network_1.RequestMethod.Delete)
            .addPath('listing')
            .addPath('' + listingId);
        return this.networkService.send(request).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User must be the author of the corresponding listing to remove it!');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    /**
     * Returns all lisitings in pages.
     */
    ListingController.prototype.getListings = function (listingRequest) {
        var _this = this;
        var networkRequest = (listingRequest) ? listingRequest.getRequest() : this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(network_1.RequestMethod.Get)
            .addPath('listings');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return _this.pageFactory.createPage(response.json());
            }
            throw new Error(response.toString());
        });
    };
    ListingController.prototype.getListing = function (listingID) {
        var _this = this;
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(network_1.RequestMethod.Get)
            .addPath('listing')
            .addPath('' + listingID);
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                var listing = _this.listingCreator.createListing(response.json());
                console.log('resolve finished');
                return listing;
            }
            throw new Error('' + response.status);
        });
    };
    ListingController.prototype.editListing = function (listing) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(network_1.RequestMethod.Post)
            .addPath('listing')
            .addPath('' + listing.id)
            .setBody(listing);
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be  authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('Only owner can change their one listings.');
            }
            throw new Error(response.toString());
        });
    };
    ListingController.prototype.activateListing = function (listingId) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(network_1.RequestMethod.Post)
            .addPath('listing')
            .addPath('' + listingId)
            .addPath('activate');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be  authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('Only owner can change their one listings.');
            }
            throw new Error(response.toString());
        });
    };
    ListingController.prototype.deactivateListing = function (listingId) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(network_1.RequestMethod.Post)
            .addPath('listing')
            .addPath('' + listingId)
            .addPath('deactivate');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be  authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('Only owner can change their one listings.');
            }
            throw new Error(response.toString());
        });
    };
    ListingController.prototype.postComment = function (listingId, comment) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(network_1.RequestMethod.Post)
            .addPath('listing')
            .addPath('' + listingId)
            .addPath('comment')
            .setBody(comment);
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 201) {
                return response.json().id;
            }
            else if (response.status === 401) {
                throw new Error('User must be  authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('Listing is deactivated or user is not an admin.');
            }
            else if (response.status === 404) {
                throw new Error('No lisiting found for: ' + listingId + '.');
            }
            throw new Error(response.toString());
        });
    };
    ListingController.prototype.removeComment = function (listingId, commentId) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(network_1.RequestMethod.Delete)
            .addPath('listing')
            .addPath('' + listingId)
            .addPath('comment')
            .addPath('' + commentId);
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be  authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User is not the creator or the listing is deactivated.');
            }
            else if (response.status === 404) {
                throw new Error('Listing id or comment id is invalid.');
            }
        });
    };
    ListingController.prototype.getInactiveListings = function (listingRequest) {
        var _this = this;
        var networkRequest = (listingRequest) ? listingRequest.getRequest() : this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(network_1.RequestMethod.Get)
            .addPath('listings')
            .addPath('inactive');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return _this.pageFactory.createPage(response.json());
            }
            else if (response.status === 401) {
                throw new Error('User must be  authenticated to use this method!');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    ListingController.prototype.searchListings = function (query, listingRequest) {
        var _this = this;
        var networkRequest = (listingRequest) ? listingRequest.getRequest() : this.networkService.networkRequest();
        networkRequest
            .addQuery('query', query)
            .addPath('listings')
            .addPath('search');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return _this.listingListFactory.createListingList(response.json());
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            throw new Error(response.toString());
        });
    };
    ListingController.prototype.getOwnListings = function () {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .addPath('listings')
            .addPath('own');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return response.json().listings;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            throw new Error(response.toString());
        });
    };
    return ListingController;
}());
ListingController = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [network_1.NetworkService,
        listings_information_service_1.ListingInformationService])
], ListingController);
exports.ListingController = ListingController;
//# sourceMappingURL=listing.controller.js.map