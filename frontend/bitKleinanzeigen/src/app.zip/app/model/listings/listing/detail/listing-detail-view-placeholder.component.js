"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listing_model_1 = require("../listing.model");
var ListingDetailViewPlaceholderComponent = (function () {
    function ListingDetailViewPlaceholderComponent(viewContainerRef, componentFactoryResolver) {
        this.viewContainerRef = viewContainerRef;
        this.componentFactoryResolver = componentFactoryResolver;
        this.listingDetailViewCreated = false;
    }
    ListingDetailViewPlaceholderComponent.prototype.ngOnChanges = function (simpleChanges) {
        if (simpleChanges['listingComponentType'] && simpleChanges['listingComponentType']['currentValue']) {
            if (this.listingDetailViewCreated) {
                this.listingDetailViewComponentRef.destroy();
            }
            var listingDetailViewComponentFactory = this.componentFactoryResolver.resolveComponentFactory(this.listingComponentType);
            this.listingDetailViewComponentRef = this.viewContainerRef.createComponent(listingDetailViewComponentFactory);
            // Inject it into the view
            this.listingDetailViewComponentRef.instance.listing = this.listing;
            this.listingDetailViewCreated = true;
        }
        // if (typeof this.listingComponentType !== 'undefined') {
        //   console.log(this.listing)
        //   let listingPreviewComponentFactory : ComponentFactory<ListingComponent> = this.componentFactoryResolver.resolveComponentFactory(this.listingComponentType);
        //   let listingPreviewComponentRef : ComponentRef<ListingComponent> = this.viewContainerRef.createComponent(listingPreviewComponentFactory);
        //   // Inject it into the view
        //   (<ListingComponent>listingPreviewComponentRef.instance).listing = this.listing;
        // }
    };
    return ListingDetailViewPlaceholderComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", listing_model_1.Listing)
], ListingDetailViewPlaceholderComponent.prototype, "listing", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.Type)
], ListingDetailViewPlaceholderComponent.prototype, "listingComponentType", void 0);
ListingDetailViewPlaceholderComponent = __decorate([
    core_1.Component({
        selector: 'listing-detail-view-placeholder',
        template: ''
    }),
    __metadata("design:paramtypes", [core_1.ViewContainerRef,
        core_1.ComponentFactoryResolver])
], ListingDetailViewPlaceholderComponent);
exports.ListingDetailViewPlaceholderComponent = ListingDetailViewPlaceholderComponent;
//# sourceMappingURL=listing-detail-view-placeholder.component.js.map