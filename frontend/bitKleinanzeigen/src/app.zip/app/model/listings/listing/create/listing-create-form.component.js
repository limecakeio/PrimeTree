"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var forms_service_1 = require("../../../../form/forms.service");
var ListingCreateFormComponent = (function () {
    function ListingCreateFormComponent(formService) {
        this.formService = formService;
        this.listingFormCreateFinished = new core_1.EventEmitter();
        this.listingFormUpdateRepositoryOutput = new core_1.EventEmitter();
    }
    ListingCreateFormComponent.prototype.submitListing = function (updateRepository, callback) {
        if (this.form.valid) {
            this.model.createDate = new Date().getTime();
            this.model.type = this.listingType;
            this.model.isActive = true;
            this.model.expiryDate = null;
            this.model.condition = 'bad';
            var outputEmitObject = {
                model: this.model,
                updateRepository: updateRepository
            };
            if (callback) {
                outputEmitObject.callback = callback;
            }
            this.listingFormCreateFinished.emit(outputEmitObject);
        }
    };
    ListingCreateFormComponent.prototype.updateRepository = function () {
        this.listingFormUpdateRepositoryOutput.emit();
    };
    return ListingCreateFormComponent;
}());
__decorate([
    core_1.Output('listingFormCreateFinished'),
    __metadata("design:type", core_1.EventEmitter)
], ListingCreateFormComponent.prototype, "listingFormCreateFinished", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], ListingCreateFormComponent.prototype, "listingFormUpdateRepositoryOutput", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], ListingCreateFormComponent.prototype, "userLocation", void 0);
ListingCreateFormComponent = __decorate([
    core_1.Component({
        selector: 'listing-create-form',
        templateUrl: './listing-create-form.component.html',
        providers: [
            forms_service_1.FormService
        ],
        outputs: [
            'listingFormCreateFinished'
        ]
    }),
    __metadata("design:paramtypes", [forms_service_1.FormService])
], ListingCreateFormComponent);
exports.ListingCreateFormComponent = ListingCreateFormComponent;
//# sourceMappingURL=listing-create-form.component.js.map