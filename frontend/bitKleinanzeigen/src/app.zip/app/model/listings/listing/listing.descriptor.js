"use strict";
var listing_preview_component_1 = require("./listing-preview.component");
exports.ListingPreviewComponent = listing_preview_component_1.ListingPreviewComponent;
var listing_create_form_component_1 = require("./listing-create-form.component");
exports.ListingCreateFormComponent = listing_create_form_component_1.ListingCreateFormComponent;
var listing_factory_1 = require("./listing.factory");
var listing_component_1 = require("./listing.component");
exports.ListingComponent = listing_component_1.ListingComponent;
/**
 *
 */
var ListingDescriptor = (function () {
    function ListingDescriptor() {
    }
    ListingDescriptor.prototype.listingPreviewComponentType = function () {
        return listing_preview_component_1.ListingPreviewComponent;
    };
    ListingDescriptor.prototype.listingType = function () {
        return 'Listing';
    };
    ;
    ListingDescriptor.prototype.listingCreateForm = function () {
        return listing_create_form_component_1.ListingCreateFormComponent;
    };
    ListingDescriptor.prototype.listingFactory = function () {
        return new listing_factory_1.ListingFactory('Listing');
    };
    /**Returns the class name associated with a particular listing component*/
    ListingDescriptor.prototype.getListingComponentTypeClassName = function () {
        return listing_component_1.ListingComponent;
    };
    return ListingDescriptor;
}());
exports.ListingDescriptor = ListingDescriptor;
//# sourceMappingURL=listing.descriptor.js.map