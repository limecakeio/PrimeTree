"use strict";
var Condition;
(function (Condition) {
    Condition[Condition["NEW"] = 0] = "NEW";
    Condition[Condition["USED"] = 1] = "USED";
})(Condition = exports.Condition || (exports.Condition = {}));
//# sourceMappingURL=condition.model.js.map