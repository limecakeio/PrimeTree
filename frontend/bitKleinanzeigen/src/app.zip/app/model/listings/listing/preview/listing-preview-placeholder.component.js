"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listing_model_1 = require("../listing.model");
var ListingPreviewPlaceholderComponent = (function () {
    function ListingPreviewPlaceholderComponent(viewContainerRef, componentFactoryResolver) {
        this.viewContainerRef = viewContainerRef;
        this.componentFactoryResolver = componentFactoryResolver;
        this.listingCreated = new core_1.EventEmitter();
        this.showListingDetailView = new core_1.EventEmitter();
    }
    /**
     * We need to tell  the viewport component when a listing element has been created.
     */
    ListingPreviewPlaceholderComponent.prototype.ngOnInit = function () {
        var _this = this;
        // Create a component as well as a reference to it
        var listingPreviewComponentFactory = this.componentFactoryResolver.resolveComponentFactory(this.listingComponentType);
        var listingPreviewComponentRef = this.viewContainerRef.createComponent(listingPreviewComponentFactory);
        this.listingPreviewComponent = listingPreviewComponentRef.instance;
        // Inject it into the view
        // (<ListingPreviewComponent>listingPreviewComponentRef.instance).listing = this.listing;
        // Angular doesn't support Input, Output and ngOnChanges life cycle hooks in dynamically created components
        this.listingPreviewComponent.listing = this.listing;
        this.listingPreviewComponent.ngOnChanges({
            listing: this.listingSimpleChange
        });
        // forward the output
        this.listingPreviewComponent.showListingDetailView.subscribe(function (id) {
            _this.showListingDetailView.emit(id);
        });
        //Inform the parent-component that the new component has been created
        this.listingCreated.emit();
    };
    ListingPreviewPlaceholderComponent.prototype.ngOnChanges = function (simpleChanges) {
        this.listingSimpleChange = simpleChanges['listing'];
        console.log(this.listingSimpleChange);
    };
    return ListingPreviewPlaceholderComponent;
}());
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], ListingPreviewPlaceholderComponent.prototype, "listingCreated", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], ListingPreviewPlaceholderComponent.prototype, "showListingDetailView", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.Type)
], ListingPreviewPlaceholderComponent.prototype, "listingComponentType", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", listing_model_1.Listing)
], ListingPreviewPlaceholderComponent.prototype, "listing", void 0);
ListingPreviewPlaceholderComponent = __decorate([
    core_1.Component({
        selector: 'listing-preview-placeholder',
        template: ''
    }),
    __metadata("design:paramtypes", [core_1.ViewContainerRef,
        core_1.ComponentFactoryResolver])
], ListingPreviewPlaceholderComponent);
exports.ListingPreviewPlaceholderComponent = ListingPreviewPlaceholderComponent;
//# sourceMappingURL=listing-preview-placeholder.component.js.map