"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listings_information_service_1 = require("../../listings-information.service");
var listing_controller_1 = require("../listing.controller");
var ListingDetailViewOverlayComponent = (function () {
    function ListingDetailViewOverlayComponent(listingInformationService, listingController) {
        this.listingInformationService = listingInformationService;
        this.listingController = listingController;
        this.displayDetailViewOverlay = 'none';
        this.listingDescriptorHandler = this.listingInformationService.listingDescriptorHandler;
    }
    ListingDetailViewOverlayComponent.prototype.deactivateDetailViewOverlay = function () {
        this.displayDetailViewOverlay = 'none';
    };
    ListingDetailViewOverlayComponent.prototype.activateDetailViewOverlay = function () {
        console.log('reshow detail overlay view');
        this.displayDetailViewOverlay = 'block';
    };
    ListingDetailViewOverlayComponent.prototype.ngOnChanges = function (simpleChanges) {
        var _this = this;
        /**Check whether only the detail view nedds to redraw*/
        if (!simpleChanges['listingID'] && simpleChanges['lisitingDetailViewOverlayDisplayState']) {
            this.activateDetailViewOverlay();
            return;
        }
        if (simpleChanges['listingID']['currentValue'] === null) {
            return;
        }
        this.displayDetailViewOverlay = "block";
        this.listingController.getListing(this.listingID)
            .subscribe(function (listing) {
            _this.listing = listing;
            _this.listingComponentType = _this.listingDescriptorHandler.getListingComponentTypeFromListingType(listing.type);
        }, function (error) {
            console.error(error);
        }, function () {
            console.log('get request finished');
        });
    };
    return ListingDetailViewOverlayComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], ListingDetailViewOverlayComponent.prototype, "listingID", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], ListingDetailViewOverlayComponent.prototype, "lisitingDetailViewOverlayDisplayState", void 0);
ListingDetailViewOverlayComponent = __decorate([
    core_1.Component({
        selector: 'listing-detail-view-overlay',
        templateUrl: './listing-detail-view-overlay.component.html',
        styleUrls: ['./listing-detail-view-overlay.component.css']
    }),
    __metadata("design:paramtypes", [listings_information_service_1.ListingInformationService,
        listing_controller_1.ListingController])
], ListingDetailViewOverlayComponent);
exports.ListingDetailViewOverlayComponent = ListingDetailViewOverlayComponent;
//# sourceMappingURL=listing-detail-view-overlay.component.js.map