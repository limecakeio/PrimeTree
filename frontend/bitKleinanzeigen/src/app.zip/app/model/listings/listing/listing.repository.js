"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listing_controller_1 = require("./listing.controller");
var user_1 = require("../../user/user");
/**
 * This class distributes the listing and collects them.
 */
var ListingRepository = (function () {
    function ListingRepository(listingController, userService) {
        this.listingController = listingController;
        this.userService = userService;
        this.listings = [];
        this.update();
    }
    /**
     * Adds a listing to the repository.
     * @argument {Listing} listing
     */
    ListingRepository.prototype.addListing = function (listing) {
        this.listings.push(listing);
    };
    /**
     * Removes the argument listing from the repository.
     * @argument {Listing} listing
     */
    ListingRepository.prototype.removeListing = function (listing) {
        var _this = this;
        this.listingController.removeListing(listing.id).subscribe(function () {
            _this.update();
        }, function (error) {
            console.error(error);
        }, function () {
        });
    };
    /**
     * Updates all listings
     */
    ListingRepository.prototype.update = function () {
        if (this.userService.userInformation.isAdmin) {
            this.updateAsAdmin();
        }
        else {
            this.updateAsEmployee();
        }
    };
    ListingRepository.prototype.updateAsAdmin = function () {
    };
    ListingRepository.prototype.updateAsEmployee = function () {
        var _this = this;
        this.listingController.getActiveListings().subscribe(function (page) {
            _this.page = page;
            _this.listingCount = page.listings.length;
            _this.buildPairArraysFromPage(page);
            _this.getNextListings();
        }, function (error) {
            console.error(error);
        }, function () {
            // this.getNextListings();
        });
    };
    ListingRepository.prototype.getNextListings = function () {
        var _this = this;
        if (this.page.pageNumber === this.page.pages) {
            this.page.pageNumber = 1;
        }
        this.listingController.loadNewPageSite(this.page).subscribe(function (page) {
            _this.page = page;
            _this.buildPairArraysFromPage(page);
        }, function (error) {
            console.error(error);
        }, function () {
        });
    };
    ListingRepository.prototype.buildPairArraysFromPage = function (page) {
        var _this = this;
        console.log(page);
        var i = 0;
        var pairArray = [];
        page.listings.forEach(function (listing) {
            if (i % 2 === 0) {
                pairArray = [];
                pairArray.push(listing);
            }
            else {
                pairArray.push(listing);
                _this.listings.push(pairArray);
            }
            if (page.listings.length === i + 1 && i % 2 === 0) {
                _this.listings.push(pairArray);
            }
            i++;
        });
    };
    return ListingRepository;
}());
ListingRepository = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [listing_controller_1.ListingController,
        user_1.UserService])
], ListingRepository);
exports.ListingRepository = ListingRepository;
//# sourceMappingURL=listing.repository.js.map