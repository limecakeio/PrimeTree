"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var Subject_1 = require("rxjs/Subject");
var listing_controller_1 = require("./listing.controller");
var user_1 = require("../../user/user");
var State;
(function (State) {
    State[State["WAITING"] = 0] = "WAITING";
    State[State["WORKING"] = 1] = "WORKING";
})(State || (State = {}));
/**
 * This class distributes the listing and collects them.
 */
var ListingRepository = (function () {
    function ListingRepository(listingController, userService) {
        this.listingController = listingController;
        this.userService = userService;
        this.listings = [];
        this.loadingSubject = new Subject_1.Subject();
        this.loadingObservable = this.loadingSubject.asObservable();
        this.state = State.WAITING;
        this.update();
    }
    /**
     * Adds a listing to the repository.
     * @argument {Listing} listing
     */
    ListingRepository.prototype.addListing = function (listing) {
        this.listings.push(listing);
    };
    /**
     * Removes the argument listing from the repository.
     * @argument {Listing} listing
     */
    ListingRepository.prototype.removeListing = function (listing) {
        var _this = this;
        this.listingController.removeListing(listing.id).subscribe(function () {
            _this.update();
        }, function (error) {
            console.error(error);
        }, function () {
        });
    };
    /** Creates a ListingRequest out of the criterias and updates the listing array
     and the page with listings which match the filter criteria*/
    ListingRepository.prototype.applyFilter = function (filterCriteria) {
        var _this = this;
        var listingRequest = this.listingController.listingRequest();
        // this.listingCount = 0;
        if (filterCriteria.kind) {
            listingRequest.setListingKind(filterCriteria.kind);
        }
        filterCriteria.location.forEach(function (location) {
            listingRequest.addLocation(location);
        });
        if (filterCriteria.price_max && filterCriteria.price_min) {
            listingRequest.setPriceMax(filterCriteria.price_max);
            listingRequest.setPriceMin(filterCriteria.price_min);
        }
        filterCriteria.type.forEach(function (listingType) {
            listingRequest.addListingType(listingType);
        });
        this.listingController.getActiveListings(listingRequest).subscribe(function (page) {
            _this.page = page;
            _this.listings = []; // remove former listing pairs
            _this.buildPairArraysFromPage(page);
            _this.listingCount = page.listings.length;
        }, function (error) {
            console.log(error);
        });
    };
    /**
     * Updates all listings
     */
    ListingRepository.prototype.update = function () {
        var _this = this;
        this.listings = [];
        this.listingCount = 0;
        this.listingController.getActiveListings().subscribe(function (page) {
            console.log(page, 'page');
            _this.page = page;
            _this.listingCount = page.listings.length;
            _this.buildPairArraysFromPage(page);
        }, function (error) {
            console.error(error);
        }, function () {
            // this.getNextListings();
        });
    };
    /** Loads more listings from the server. The Observable returns true if the loading was successful else false*/
    ListingRepository.prototype.getNextListings = function () {
        var _this = this;
        console.log(this.page.pageNumber + ' ' + this.page.pages, 'pages' + ' ' + this.state);
        if (this.page.pageNumber <= this.page.pages && this.state === State.WAITING) {
            this.state = State.WORKING;
            console.log(this.page.pageNumber + ' ' + this.page.pages, 'pages');
            this.listingController.loadNewPageSite(this.page).subscribe(function (page) {
                _this.state = State.WAITING;
                _this.page = page;
                _this.buildPairArraysFromPage(page);
                _this.loadingSubject.next(true);
            }, function (error) {
                console.error(error);
            }, function () {
            });
        }
        else {
            this.loadingSubject.next(false);
        }
        return this.loadingObservable;
    };
    ListingRepository.prototype.buildPairArraysFromPage = function (page) {
        var _this = this;
        console.log('buildPairArraysFromPage');
        var i = 0;
        var pairArray = [];
        page.listings.forEach(function (listing) {
            if (i % 2 === 0) {
                pairArray = [];
                pairArray.push(listing);
            }
            else {
                pairArray.push(listing);
                _this.listings.push(pairArray);
            }
            if (page.listings.length === i + 1 && i % 2 === 0) {
                _this.listings.push(pairArray);
            }
            i++;
        });
    };
    return ListingRepository;
}());
ListingRepository = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [listing_controller_1.ListingController,
        user_1.UserService])
], ListingRepository);
exports.ListingRepository = ListingRepository;
//# sourceMappingURL=listing.repository.js.map