"use strict";
/**
 * an uniform class which describes all comments
 */
var Comment = (function () {
    function Comment() {
    }
    return Comment;
}());
exports.Comment = Comment;
//# sourceMappingURL=comment.model.js.map