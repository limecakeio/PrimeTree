"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listings_information_service_1 = require("../listings-information.service");
/**
 * This class creates a listing from the transport bodies or the other way around
 */
var ListingCreator = (function () {
    function ListingCreator(listingInformationService) {
        this.listingInformationService = listingInformationService;
        this.listingDescriptorHandler = this.listingInformationService.listingDescriptorHandler;
    }
    /**
     * Creates a new listing with all properties set accordingly of the argument body.
     * Throws an error if no ListingFactory matches the type mentioned in the body or when necessary properties are missing in the body.
     * @param {any} body Must be an object which includes all properties which are necessary to create the listing.
     * @throws {Error}
     */
    ListingCreator.prototype.createListing = function (body) {
        var message;
        if (typeof body === 'object' && body.hasOwnProperty('type')) {
            // let factory : ListingFactory = this.getListingFactory(body.type);
            var listingFactory = this.listingDescriptorHandler.findListingFactoryFromListingType(body.type);
            if (listingFactory !== null) {
                return listingFactory.createListing(body);
            }
            else {
                message = 'No listing factory found for listing of type: ' + body.type;
            }
        }
        else {
            message = 'No valid body for building listings!';
        }
        throw new Error(message);
    };
    /**
     * Registers a ListingFactory to call it later.
     * @param {ListingFactory} listingFactory an instance of ListingFactory
     * @return {void}
     */
    ListingCreator.prototype.registerFactory = function (listingFactory) {
        // this.listingFactories.push(listingFactory);
    };
    return ListingCreator;
}());
ListingCreator = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [listings_information_service_1.ListingInformationService])
], ListingCreator);
exports.ListingCreator = ListingCreator;
//# sourceMappingURL=listing.creator.js.map