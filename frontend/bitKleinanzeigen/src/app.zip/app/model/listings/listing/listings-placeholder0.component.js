"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listing_1 = require("./listing/listing");
var ListingsPreviewPlaceholderComponent = (function () {
    function ListingsPreviewPlaceholderComponent(viewContainerRef, componentFactoryResolver) {
        this.viewContainerRef = viewContainerRef;
        this.componentFactoryResolver = componentFactoryResolver;
    }
    ListingsPreviewPlaceholderComponent.prototype.ngOnInit = function () {
        var componentFactory = this.componentFactoryResolver.resolveComponentFactory(this.listingComponentType);
        var componentRef = this.viewContainerRef.createComponent(componentFactory);
        componentRef.instance.listing = this.listing;
    };
    return ListingsPreviewPlaceholderComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ListingsPreviewPlaceholderComponent.prototype, "listingComponentType", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", typeof (_a = typeof listing_1.Listing !== "undefined" && listing_1.Listing) === "function" && _a || Object)
], ListingsPreviewPlaceholderComponent.prototype, "listing", void 0);
ListingsPreviewPlaceholderComponent = __decorate([
    core_1.Component({
        selector: 'listing-preview-placeholder'
    }),
    __metadata("design:paramtypes", [core_1.ViewContainerRef,
        core_1.ComponentFactoryResolver])
], ListingsPreviewPlaceholderComponent);
exports.ListingsPreviewPlaceholderComponent = ListingsPreviewPlaceholderComponent;
var _a;
//# sourceMappingURL=listings-placeholder0.component.js.map