import {
  Component,
  Type
 } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ListingModule } from './listing.module';
import { ListingDescriptorHandler } from './listing-descriptor.handler';
import { ListingComponent } from './listing.component';
import { ListingController } from './listing.controller';
import { ListingInformationService } from '../listings-information.service';
import { Listing } from './listing.model';

@Component({
  selector: 'listing-detail-view',
  templateUrl: './listing-detail-view.component.html',
  styleUrls: [ './listing-detail-view.component.css' ]
})
export class ListingDetailViewComponent {

  private listingDescriptorHandler : ListingDescriptorHandler;

  private listingComponentType : Type<ListingComponent>;

  private listing : Listing;

  constructor(
    private activatedRoute : ActivatedRoute,
    private listingController : ListingController,
    private listingInformationService : ListingInformationService
  ) {
    this.listingDescriptorHandler = this.listingInformationService.listingDescriptorHandler;
    console.log('abcdef')
    this.listing = this.activatedRoute.snapshot.data['listing'];
    this.listingComponentType = this.listingDescriptorHandler.getListingComponentTypeFromListingType(this.listing.type);
  }

  // private getListing(listingID : number) : void {
  //   this.listingController.getListing(listingID).subscribe((listing : Listing) => {
  //     this.listing = listing;
  //     this.listingComponentType = this.listingDescriptorHandler.getListingComponentTypeFromListingType(listing.type);
  //     // let displayContainer : Element = document.querySelector('listing-detail-view-container');
  //     // let placeholder = document.createElement("listing-detail-view-placeholder");
  //     // placeholder.setAttribute("[listing]", "listing");
  //     // placeholder.setAttribute("[listingComponentType]", "listingComponentType");
  //     // displayContainer.appendChild(placeholder);
  //   }, (error : Error) => {
  //     console.error(error);
  //   });
  // }


}
