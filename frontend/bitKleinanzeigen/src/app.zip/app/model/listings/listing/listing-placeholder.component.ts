import {
  Component,
  OnInit,
  Input,
  Type,
  ComponentFactory,
  ComponentFactoryResolver
} from '@angular/core';

@Component({
  selector: 'listing-placeholder',
  template: ''
})
export class ListingPlaceholderComponent implements OnInit {

  constructor(

  ) {

  }

  ngOnInit() : void {

  }

}
