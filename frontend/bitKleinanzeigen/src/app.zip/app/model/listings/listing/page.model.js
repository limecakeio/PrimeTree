"use strict";
var Page = (function () {
    function Page() {
    }
    /**
     * adds a listing
     * @param {Listing} listing
     */
    Page.prototype.addListing = function (listing) {
        this.listings.push(listing);
    };
    return Page;
}());
exports.Page = Page;
//# sourceMappingURL=page.model.js.map