"use strict";
/**
 * defines a base class which contains all common properties shared by all Listing types
 */
var Listing = (function () {
    function Listing() {
    }
    return Listing;
}());
exports.Listing = Listing;
//# sourceMappingURL=listing.model.js.map