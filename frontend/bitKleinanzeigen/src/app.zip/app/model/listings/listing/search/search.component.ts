import { Component } from '@angular/core';


@Component({
  selector: 'listing-search',
  templateUrl: './search.component.html',
  styleUrls: [ './search.component.css' ]
})
export class ListingSearchComponent {
  
}
