"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var listing_creator_1 = require("./listing.creator");
var listing_controller_1 = require("./listing.controller");
var listing_repository_1 = require("./listing.repository");
var listing_overview_viewport_component_1 = require("./preview/listing-overview-viewport.component");
var listing_preview_placeholder_component_1 = require("./preview/listing-preview-placeholder.component");
var listing_create_component_1 = require("./create/listing-create.component");
var listing_create_form_placeholder_component_1 = require("./create/listing-create-form-placeholder.component");
var listing_detail_view_component_1 = require("./detail/listing-detail-view.component");
var listing_detail_view_placeholder_component_1 = require("./detail/listing-detail-view-placeholder.component");
var listing_detail_view_overlay_component_1 = require("./detail/listing-detail-view-overlay.component");
var form_module_1 = require("../../../form/form.module");
var filter_component_1 = require("./filter/filter.component");
var listing_routing_1 = require("./listing.routing");
// Add your own listing components in the entryComponents array
var listing_descriptor_1 = require("./listing.descriptor");
var sale_offer_descriptor_1 = require("../offer/sale-offer/sale-offer.descriptor");
var service_offer_descriptor_1 = require("../offer/service-offer/service-offer.descriptor");
var ListingModule = (function () {
    function ListingModule() {
    }
    return ListingModule;
}());
ListingModule = __decorate([
    core_1.NgModule({
        imports: [
            form_module_1.FormModule,
            common_1.CommonModule,
            listing_routing_1.ListingRoutingModule
        ],
        declarations: [
            listing_descriptor_1.ListingCreateFormComponent,
            listing_descriptor_1.ListingComponent,
            listing_descriptor_1.ListingPreviewComponent,
            listing_overview_viewport_component_1.ListingOverviewViewportComponent,
            listing_preview_placeholder_component_1.ListingPreviewPlaceholderComponent,
            listing_create_form_placeholder_component_1.ListingCreateFormPlaceholderComponent,
            listing_create_component_1.ListingCreateComponent,
            listing_detail_view_component_1.ListingDetailViewComponent,
            listing_detail_view_placeholder_component_1.ListingDetailViewPlaceholderComponent,
            listing_detail_view_overlay_component_1.ListingDetailViewOverlayComponent,
            filter_component_1.ListingFilterComponent
        ],
        exports: [
            form_module_1.FormModule,
            listing_overview_viewport_component_1.ListingOverviewViewportComponent,
            listing_preview_placeholder_component_1.ListingPreviewPlaceholderComponent,
            listing_create_form_placeholder_component_1.ListingCreateFormPlaceholderComponent,
            listing_create_component_1.ListingCreateComponent,
            listing_detail_view_component_1.ListingDetailViewComponent,
            listing_detail_view_placeholder_component_1.ListingDetailViewPlaceholderComponent,
            listing_detail_view_overlay_component_1.ListingDetailViewOverlayComponent,
            filter_component_1.ListingFilterComponent
        ],
        providers: [
            listing_creator_1.ListingCreator,
            listing_controller_1.ListingController,
            listing_repository_1.ListingRepository
        ],
        entryComponents: [
            sale_offer_descriptor_1.SaleOfferPreviewComponent,
            sale_offer_descriptor_1.SaleOfferCreateFormComponent,
            sale_offer_descriptor_1.SaleOfferComponent,
            service_offer_descriptor_1.ServiceOfferPreviewComponent,
            service_offer_descriptor_1.ServiceOfferCreateFormComponent,
            service_offer_descriptor_1.ServiceOfferComponent
        ]
    })
], ListingModule);
exports.ListingModule = ListingModule;
//# sourceMappingURL=listing.module.js.map