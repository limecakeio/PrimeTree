"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var listing_component_1 = require("./listing.component");
var listing_preview_component_1 = require("./listing-preview.component");
var listing_creator_1 = require("./listing.creator");
var listing_controller_1 = require("./listing.controller");
var listing_repository_1 = require("./listing.repository");
var listing_preview_placeholder_component_1 = require("./listing-preview-placeholder.component");
var listing_descriptor_1 = require("./listing.descriptor");
var listing_create_component_1 = require("./listing-create.component");
var listing_create_form_placeholder_component_1 = require("./listing-create-form-placeholder.component");
var listing_detail_view_component_1 = require("./listing-detail-view.component");
var listing_detail_view_placeholder_component_1 = require("./listing-detail-view-placeholder.component");
var listing_routing_1 = require("./listing.routing");
var sale_offer_descriptor_1 = require("../offer/sale-offer/sale-offer.descriptor");
var service_offer_descriptor_1 = require("../offer/service-offer/service-offer.descriptor");
var ListingModule = (function () {
    function ListingModule() {
    }
    return ListingModule;
}());
ListingModule = __decorate([
    core_1.NgModule({
        imports: [
            listing_routing_1.ListingRoutingModule
        ],
        declarations: [
            listing_component_1.ListingComponent,
            listing_preview_placeholder_component_1.ListingPreviewPlaceholderComponent,
            listing_create_form_placeholder_component_1.ListingCreateFormPlaceholderComponent,
            listing_create_component_1.ListingCreateComponent,
            listing_detail_view_component_1.ListingDetailViewComponent,
            listing_detail_view_placeholder_component_1.ListingDetailViewPlaceholderComponent
        ],
        exports: [
            listing_component_1.ListingComponent,
            listing_preview_placeholder_component_1.ListingPreviewPlaceholderComponent,
            listing_create_form_placeholder_component_1.ListingCreateFormPlaceholderComponent,
            listing_create_component_1.ListingCreateComponent,
            listing_detail_view_component_1.ListingDetailViewComponent,
            listing_detail_view_placeholder_component_1.ListingDetailViewPlaceholderComponent
        ],
        providers: [
            listing_creator_1.ListingCreator,
            listing_controller_1.ListingController,
            listing_repository_1.ListingRepository
        ],
        entryComponents: [
            listing_descriptor_1.ListingCreateFormComponent,
            listing_component_1.ListingComponent,
            listing_preview_component_1.ListingPreviewComponent,
            sale_offer_descriptor_1.SaleOfferPreviewComponent,
            sale_offer_descriptor_1.SaleOfferCreateFormComponent,
            service_offer_descriptor_1.ServiceOfferPreviewComponent,
            service_offer_descriptor_1.ServiceOfferCreateFormComponent
        ]
    })
], ListingModule);
exports.ListingModule = ListingModule;
//# sourceMappingURL=listing.module.js.map