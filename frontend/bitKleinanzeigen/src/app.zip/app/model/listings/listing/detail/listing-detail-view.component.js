"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var listing_controller_1 = require("../listing.controller");
var listings_information_service_1 = require("../../listings-information.service");
var ListingDetailViewComponent = (function () {
    function ListingDetailViewComponent(activatedRoute, listingController, listingInformationService) {
        this.activatedRoute = activatedRoute;
        this.listingController = listingController;
        this.listingInformationService = listingInformationService;
        this.listingDescriptorHandler = this.listingInformationService.listingDescriptorHandler;
        this.listing = this.activatedRoute.snapshot.data['listing'];
    }
    ListingDetailViewComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.listingController.getListing(this.activatedRoute.snapshot.params['id'])
            .subscribe(function (listing) {
            _this.listing = listing;
            _this.listingComponentType = _this.listingDescriptorHandler.getListingComponentTypeFromListingType(listing.type);
        }, function (error) {
            console.error(error);
        }, function () {
            console.log('get request finished');
        });
    };
    return ListingDetailViewComponent;
}());
ListingDetailViewComponent = __decorate([
    core_1.Component({
        selector: 'listing-detail-view',
        templateUrl: './listing-detail-view.component.html',
        styleUrls: ['./listing-detail-view.component.css']
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute,
        listing_controller_1.ListingController,
        listings_information_service_1.ListingInformationService])
], ListingDetailViewComponent);
exports.ListingDetailViewComponent = ListingDetailViewComponent;
//# sourceMappingURL=listing-detail-view.component.js.map