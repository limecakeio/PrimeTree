"use strict";
var listing_descriptor_1 = require("./listing.descriptor");
var ListingDescriptorHandler = (function () {
    function ListingDescriptorHandler() {
        this.listingsDescriptors = [];
        this.nullListingDescriptor = new listing_descriptor_1.ListingDescriptor();
    }
    ListingDescriptorHandler.prototype.addListingDescriptor = function (listingsDescriptor) {
        this.listingsDescriptors.push(listingsDescriptor);
    };
    /**Creates a new instance based on the type of the listing descriptor*/
    ListingDescriptorHandler.prototype.addListingDescriptorTypeof = function (listingsDescriptorTypeoff) {
        this.addListingDescriptor(new listingsDescriptorTypeoff());
    };
    /**Returns a listing factory which is used to create a detailed listing object*/
    ListingDescriptorHandler.prototype.findListingFactoryFromListingType = function (listingType) {
        return this.findListingDescriptorFromListingType(listingType).listingFactory();
    };
    /**Returns the type */
    ListingDescriptorHandler.prototype.findListingPreviewComponentTypeFromListingType = function (listingType) {
        return this.findListingDescriptorFromListingType(listingType).listingPreviewComponentType();
    };
    ListingDescriptorHandler.prototype.findListingCreateFormComponentTypeFromLisitingType = function (listingType) {
        return this.findListingDescriptorFromListingType(listingType).listingCreateForm();
    };
    /**Attempts to match and return a listingComponentType based on a listing type*/
    ListingDescriptorHandler.prototype.getListingComponentTypeFromListingType = function (listingType) {
        return this.findListingDescriptorFromListingType(listingType).getListingComponentTypeClassName();
    };
    /**
     * Returns a ListingDescriptor which type matches the argument listing type.
     * Returns the base lisiting descriptor if no matching descriptor is found.
     */
    ListingDescriptorHandler.prototype.findListingDescriptorFromListingType = function (listingType) {
        for (var i = 0; i < this.listingsDescriptors.length; i++) {
            if (this.listingsDescriptors[i].listingType() === listingType) {
                return this.listingsDescriptors[i];
            }
        }
        console.error('No matching listing descriptor found for: ' + listingType + '. Please add one in LisitingModule.');
        return this.nullListingDescriptor;
    };
    ListingDescriptorHandler.prototype.getAllListingPreviewComponentTypes = function () {
        var listingPreviewComponentTypes = [];
        this.listingsDescriptors.forEach(function (listingsDescriptor) {
            listingPreviewComponentTypes.push(listingsDescriptor.listingPreviewComponentType());
        });
        return listingPreviewComponentTypes;
    };
    ListingDescriptorHandler.prototype.getAllListingComponentTypes = function () {
        var listingComponentTypes = [];
        this.listingsDescriptors.forEach(function (listingsDescriptor) {
            listingComponentTypes.push(listingsDescriptor.getListingComponentTypeClassName());
        });
        return listingComponentTypes;
    };
    ListingDescriptorHandler.prototype.getAllListingCreateFormComponentTypes = function () {
        var listingCreateFormComponentType = [];
        this.listingsDescriptors.forEach(function (listingsDescriptor) {
            listingCreateFormComponentType.push(listingsDescriptor.listingCreateForm());
        });
        return listingCreateFormComponentType;
    };
    ListingDescriptorHandler.prototype.getAllComponentTypes = function () {
        var componentTypes = [];
        this.listingsDescriptors.forEach(function (listingDescriptor) {
            componentTypes.push(listingDescriptor.listingCreateForm(), listingDescriptor.listingPreviewComponentType(), listingDescriptor.getListingComponentTypeClassName());
        });
        return componentTypes;
    };
    return ListingDescriptorHandler;
}());
exports.ListingDescriptorHandler = ListingDescriptorHandler;
//# sourceMappingURL=listing-descriptor.handler.js.map