/**
 * an uniform class which describes all comments
 */
export class Comment {
  commentID : number;
  userID : number;
  createDate : Date;
  comment : string;
}
