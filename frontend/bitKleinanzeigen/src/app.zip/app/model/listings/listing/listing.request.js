"use strict";
var ListingRequest = (function () {
    function ListingRequest(networkRequest) {
        this.networkRequest = networkRequest;
    }
    ListingRequest.prototype.getRequest = function () {
        return this.networkRequest;
    };
    return ListingRequest;
}());
exports.ListingRequest = ListingRequest;
//# sourceMappingURL=listing.request.js.map