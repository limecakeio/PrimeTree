"use strict";
var ListingRequest = (function () {
    function ListingRequest(networkRequest) {
        this.networkRequest = networkRequest;
    }
    ListingRequest.prototype.getRequest = function () {
        return this.networkRequest;
    };
    ListingRequest.prototype.setPriceMin = function (min) {
        this.networkRequest.addQuery('price_min', '' + min);
    };
    ListingRequest.prototype.setPriceMax = function (max) {
        this.networkRequest.addQuery('price_max', '' + max);
    };
    ListingRequest.prototype.setListingKind = function (kind) {
        this.networkRequest.addQuery('kind', kind);
    };
    ListingRequest.prototype.addLocation = function (location) {
        this.networkRequest.appendQuery('location', location);
    };
    ListingRequest.prototype.addListingType = function (listingType) {
        this.networkRequest.appendQuery('type', listingType);
    };
    return ListingRequest;
}());
exports.ListingRequest = ListingRequest;
//# sourceMappingURL=listing.request.js.map