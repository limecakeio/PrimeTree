import {
  Component,
  Input,
  Type,
  ViewContainerRef,
  ComponentFactoryResolver,
  ComponentFactory,
  ComponentRef,
  OnInit
} from '@angular/core';

import { Listing } from './listing.model';
import { ListingComponent } from './listing.component';

@Component({
  selector: 'listing-detail-view-placeholder',
  template: ''
})
export class ListingDetailViewPlaceholderComponent implements OnInit {

  @Input() listing : Listing;

  @Input() listingComponentType : Type<ListingComponent>;

  constructor(
    private viewContainerRef : ViewContainerRef,
    private componentFactoryResolver : ComponentFactoryResolver
  ) {

  }

  ngOnInit() : void {
    let listingPreviewComponentFactory : ComponentFactory<ListingComponent> = this.componentFactoryResolver.resolveComponentFactory(this.listingComponentType);
    let listingPreviewComponentRef : ComponentRef<ListingComponent> = this.viewContainerRef.createComponent(listingPreviewComponentFactory);
    // Inject it into the view
    (<ListingComponent>listingPreviewComponentRef.instance).listing = this.listing;
  }


}
