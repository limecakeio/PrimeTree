"use strict";
var ListingResolver = (function () {
    function ListingResolver(listingController) {
        this.listingController = listingController;
    }
    ListingResolver.prototype.resolve = function (activatedRouteSnapshot) {
        return this.listingController.getListing(parseInt(activatedRouteSnapshot.url[1].path));
    };
    return ListingResolver;
}());
exports.ListingResolver = ListingResolver;
//# sourceMappingURL=listing.resolver.js.map