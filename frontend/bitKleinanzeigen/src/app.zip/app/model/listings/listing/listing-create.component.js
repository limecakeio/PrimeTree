"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
// import { FormService } from '../../../form/forms.service';
var listing_controller_1 = require("./listing.controller");
var listing_repository_1 = require("./listing.repository");
var listings_information_service_1 = require("../listings-information.service");
var user_service_1 = require("../../user/user.service");
var ListingCreateComponent = (function () {
    function ListingCreateComponent(listingController, listingRepository, activatedRoute, router, userService, listingInformationService) {
        this.listingController = listingController;
        this.listingRepository = listingRepository;
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.userService = userService;
        this.listingInformationService = listingInformationService;
        this.listingDescriptorHandler = this.listingInformationService.listingDescriptorHandler;
        this.listingDescriptorHandler.findListingCreateFormComponentTypeFromLisitingType(this.activatedRoute.snapshot.params['listingType']);
        this.listingCreateFormComponentType = this.listingDescriptorHandler.findListingCreateFormComponentTypeFromLisitingType(this.activatedRoute.snapshot.params['listingType']);
        this.userLocation = this.userService.userInformation.location;
    }
    /**
     * Submits all properties.
     */
    ListingCreateComponent.prototype.create = function (event) {
        var _this = this;
        console.log(event.model, 'create');
        event.model.creator = this.userService.user.username;
        event.model.location = this.userService.userInformation.location;
        this.listingController.createListing(event.model).subscribe(function (listingId) {
            if (event.hasOwnProperty('callback')) {
                event.callback(listingId);
            }
            if (event.updateRepository) {
                _this.listingRepository.update();
            }
        }, function (error) {
            console.error(error);
        }, function () {
        });
    };
    ListingCreateComponent.prototype.updateRepository = function () {
        console.log('updateRepository called');
        this.listingRepository.update();
        this.router.navigate(['home']);
    };
    return ListingCreateComponent;
}());
ListingCreateComponent = __decorate([
    core_1.Component({
        selector: 'listing-create',
        templateUrl: './listing-create.component.html'
    }),
    __metadata("design:paramtypes", [listing_controller_1.ListingController,
        listing_repository_1.ListingRepository,
        router_1.ActivatedRoute,
        router_1.Router,
        user_service_1.UserService,
        listings_information_service_1.ListingInformationService])
], ListingCreateComponent);
exports.ListingCreateComponent = ListingCreateComponent;
//# sourceMappingURL=listing-create.component.js.map