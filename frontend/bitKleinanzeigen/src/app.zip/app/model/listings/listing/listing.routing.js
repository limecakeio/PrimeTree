"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var listing_create_component_1 = require("./create/listing-create.component");
var listing_overview_viewport_component_1 = require("./preview/listing-overview-viewport.component");
var listing_detail_view_component_1 = require("./detail/listing-detail-view.component");
var filter_component_1 = require("./filter/filter.component");
var can_activate_user_model_1 = require("../../../routing/can-activate-user.model");
var listingRoutes = [
    {
        path: 'listing',
        children: [
            {
                path: 'create/:listingType',
                component: listing_create_component_1.ListingCreateComponent
            }, {
                path: 'filter',
                component: filter_component_1.ListingFilterComponent
            }, {
                path: ':id',
                component: listing_detail_view_component_1.ListingDetailViewComponent
            }, {
                path: '',
                component: listing_overview_viewport_component_1.ListingOverviewViewportComponent
            }
        ],
        canActivate: [can_activate_user_model_1.CanActivateUser]
    }
];
var ListingRoutingModule = (function () {
    function ListingRoutingModule() {
    }
    return ListingRoutingModule;
}());
ListingRoutingModule = __decorate([
    core_1.NgModule({
        imports: [router_1.RouterModule.forChild(listingRoutes)],
        exports: [router_1.RouterModule]
    })
], ListingRoutingModule);
exports.ListingRoutingModule = ListingRoutingModule;
//# sourceMappingURL=listing.routing.js.map