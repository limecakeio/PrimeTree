"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listing_descriptor_handler_1 = require("./listing/listing-descriptor.handler");
var listing_descriptor_1 = require("./listing/listing.descriptor");
var sale_offer_descriptor_1 = require("./offer/sale-offer/sale-offer.descriptor");
var service_offer_descriptor_1 = require("./offer/service-offer/service-offer.descriptor");
var ListingInformationService = (function () {
    function ListingInformationService() {
        this.listingDescriptorHandler = new listing_descriptor_handler_1.ListingDescriptorHandler();
        this.listingDescriptorHandler.addListingDescriptorTypeof(listing_descriptor_1.ListingDescriptor);
        this.listingDescriptorHandler.addListingDescriptorTypeof(sale_offer_descriptor_1.SaleOfferDescriptor);
        this.listingDescriptorHandler.addListingDescriptorTypeof(service_offer_descriptor_1.ServiceOfferDescriptor);
    }
    return ListingInformationService;
}());
ListingInformationService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [])
], ListingInformationService);
exports.ListingInformationService = ListingInformationService;
//# sourceMappingURL=listings-information.service.js.map