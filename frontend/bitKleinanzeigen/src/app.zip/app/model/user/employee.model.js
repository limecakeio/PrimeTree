"use strict";
/**
 * @classdesc This class holds all information which describs an employee.
 */
var Employee = (function () {
    function Employee() {
    }
    return Employee;
}());
exports.Employee = Employee;
//# sourceMappingURL=employee.model.js.map