"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listings_information_service_1 = require("../../listings/listings-information.service");
var listing_controller_1 = require("../../listings/listing/listing.controller");
var user_controller_1 = require("../user.controller");
var FavouritesComponent = (function () {
    function FavouritesComponent(userController, listingController, listingInformationService) {
        this.userController = userController;
        this.listingController = listingController;
        this.listingInformationService = listingInformationService;
        this.favouriteListings = [];
        this.listingCounter = 0;
        this.listingCount = 0;
        this.getFavourites();
    }
    FavouritesComponent.prototype.getListingPreviewTypeFromListingType = function (listingType) {
        return this.listingInformationService.listingDescriptorHandler.findListingPreviewComponentTypeFromListingType(listingType);
    };
    FavouritesComponent.prototype.getFavourites = function () {
        var _this = this;
        this.userController.getFavourites().subscribe(function (listingIDs) {
            _this.listingCount = listingIDs.length;
            listingIDs.forEach(function (listingID) {
                _this.listingController.getListing(listingID).subscribe(function (listing) {
                    _this.favouriteListings.push(listing);
                }, function (error) {
                    console.log(error);
                });
            });
        }, function (error) {
            console.log(error);
        });
    };
    FavouritesComponent.prototype.updateListingCounter = function (id) {
        this.listingCounter++;
        console.log('favourite listing Counter', this.listingCounter);
        if (this.listingCounter === this.listingCount) {
            console.log(this.listingCounter);
            this.setViewport();
        }
    };
    FavouritesComponent.prototype.triggerDetailViewOverlay = function (e) {
    };
    FavouritesComponent.prototype.setViewport = function () {
        //Calculate the availble space for the viewport
        var headerHeight = document.querySelector("#header").clientHeight;
        var listingViewport = document.querySelector("#listing-viewport");
        var viewportHeight = this.windowHeight - headerHeight;
        listingViewport.style.height = viewportHeight + "px";
        /*Regardless of the device we are accessed from if a screen's height smaller
        than 650px we display the listings on a single line*/
        var viewPortMargin = 100; //Don't allow a listing to fill the entire container.
        var listings = document.querySelectorAll(".listing");
        var listingCubicSize;
        if (viewportHeight < 650) {
            //Display listings on a single row
            for (var i = 0; i < listings.length; i++) {
                listings[i].classList.add("single-row");
            }
            //Set the listing dimension
            listingCubicSize = viewportHeight - viewPortMargin;
        }
        else {
            //Display listings wihtin two rows
            for (var i = 0; i < listings.length; i++) {
                listings[i].classList.remove("single-row");
            }
            listingCubicSize = (viewportHeight / 2) - viewPortMargin;
        }
        //Apply the size to each listing and set its image-preview
        var listingPreviews = document.querySelectorAll(".listing-preview");
        for (var i = 0; i < listings.length; i++) {
            listingPreviews[i].style.width = listingCubicSize + "px";
            listingPreviews[i].style.height = listingCubicSize + "px";
            //Images to display in the OpenGraph ratio of 1:0.525
            listingPreviews[i].querySelector(".listing-image").style.height = listingCubicSize * 0.525 + "px";
        }
    };
    return FavouritesComponent;
}());
FavouritesComponent = __decorate([
    core_1.Component({
        selector: 'user-favourites',
        templateUrl: './favourites.component.html',
        styleUrls: ['./favourites.component.css']
    }),
    __metadata("design:paramtypes", [user_controller_1.UserController,
        listing_controller_1.ListingController,
        listings_information_service_1.ListingInformationService])
], FavouritesComponent);
exports.FavouritesComponent = FavouritesComponent;
//# sourceMappingURL=favourites.component.js.map