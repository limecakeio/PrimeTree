"use strict";
var User = (function () {
    function User() {
        this.username = '';
        this.password = '';
    }
    return User;
}());
exports.User = User;
//# sourceMappingURL=user.model.js.map