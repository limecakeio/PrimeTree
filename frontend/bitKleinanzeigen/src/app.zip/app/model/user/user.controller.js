"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
require("rxjs/add/operator/map");
var network_service_1 = require("../../network/network.service");
var user_min_model_1 = require("./user-min.model");
var employee_factory_1 = require("./employee.factory");
var UserController = (function () {
    function UserController(networkService) {
        this.networkService = networkService;
        this.userMinFactory = new user_min_model_1.UserMinFactory();
        this.employeeFactory = new employee_factory_1.EmployeeFactory();
    }
    UserController.prototype.getUsers = function () {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Get)
            .addPath('users');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return response.json().users;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User must be an admin to use this method!');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    UserController.prototype.getUser = function (userId) {
        var _this = this;
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Get)
            .addPath('user')
            .addPath('' + userId);
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return _this.employeeFactory.createEmployee(response.json());
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 404) {
                throw new Error(userId + ' is no valid identifier for a user.');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    UserController.prototype.postFavourite = function (listingId) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Post)
            .addPath('user')
            .addPath('favourites')
            .setBody({
            listingID: listingId
        });
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 201) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User can only add favourites to their own accounts!');
            }
            else if (response.status === 404) {
                throw new Error(listingId + ' is no valid identifier for a listing.');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    UserController.prototype.getFavourites = function () {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Get)
            .addPath('user')
            .addPath('favourites');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return response.json().ids;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User can only retrieve their own listings!');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    UserController.prototype.removeFavourite = function (listingId) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Get)
            .addPath('user')
            .addPath('favourites')
            .addPath('' + listingId);
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User can only remove their own listings from their favourites list!');
            }
            else if (response.status === 404) {
                throw new Error(listingId + ' is no valid identifier for a listing.');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    UserController.prototype.appointAdmin = function (userId) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Get)
            .addPath('user')
            .addPath('' + userId)
            .addPath('admin');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User must be an admin to appoint another user to act as an admin!');
            }
            else if (response.status === 404) {
                throw new Error(userId + ' is no valid user identifier.');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    UserController.prototype.relieveAdmin = function (userId) {
        var networkRequest = this.networkService.networkRequest();
        networkRequest
            .setHttpMethod(http_1.RequestMethod.Get)
            .addPath('user')
            .addPath('' + userId)
            .addPath('admin');
        return this.networkService.send(networkRequest).map(function (response) {
            if (response.status === 200) {
                return;
            }
            else if (response.status === 401) {
                throw new Error('User must be authenticated to use this method!');
            }
            else if (response.status === 403) {
                throw new Error('User must be an admin to appoint another user to act as an admin!');
            }
            else if (response.status === 404) {
                throw new Error(userId + ' is no valid user identifier.');
            }
            else {
                throw new Error(response.toString());
            }
        });
    };
    return UserController;
}());
UserController = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [network_service_1.NetworkService])
], UserController);
exports.UserController = UserController;
//# sourceMappingURL=user.controller.js.map