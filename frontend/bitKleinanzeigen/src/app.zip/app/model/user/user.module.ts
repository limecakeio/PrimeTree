import { NgModule } from '@angular/core';

import { UserService } from './user.service';

@NgModule({
  imports: [],
  declarations: [

  ],
  exports: [

  ],
  providers: [
    UserService
  ]
})
export class UserModule {

}
