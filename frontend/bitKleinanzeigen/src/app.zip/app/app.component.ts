import { Component } from '@angular/core';

@Component({
  selector: 'bITKleinanzeigen',
  templateUrl: './app.component.html',
  providers: [  ]
})
export class AppComponent  {

}
