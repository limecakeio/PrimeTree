"use strict";
var page_model_1 = require("../model/listings/listing/page.model");
var MockPageFilter = (function () {
    function MockPageFilter(pageDivider) {
        if (pageDivider === void 0) { pageDivider = 2; }
        this.pageDivider = pageDivider;
    }
    /**
     * Creates a page from the argument listings.
     */
    MockPageFilter.prototype.createPage = function (listings, criteria) {
        if (criteria.hasOwnProperty('kind')) {
            if (criteria.kind === 'offer') {
                listings = listings.filter(this.kindOfferFilter);
            }
            else if (criteria.kind === 'request') {
                listings = listings.filter(this.kindRequestFilter);
            }
        }
        if (criteria.hasOwnProperty('location')) {
            listings = this.locationFilter(listings, criteria.loaction);
        }
        if (criteria.hasOwnProperty('price_min') && criteria.hasOwnProperty('price_max')) {
            listings = this.priceFilter(listings, criteria.price_min, criteria.price_max);
        }
        if (criteria.hasOwnProperty('type')) {
            listings = this.typeFilter(listings, criteria.type);
        }
        if (criteria.hasOwnProperty('sort')) {
            listings = this.sort(listings, criteria.sort);
        }
        var page = new page_model_1.Page();
        page.count = listings.length;
        page.pages = Math.ceil(listings.length / this.pageDivider);
        page.price_max = this.getPriceMaximum(listings);
        page.price_min = this.getPriceMinimum(listings);
        page.listings = [];
        var index = 0;
        if (criteria.hasOwnProperty('page')) {
            index = criteria.page * this.pageDivider;
            page.pageNumber = criteria.page + 1;
        }
        else {
            page.pageNumber = 1;
        }
        if (index > page.count) {
            throw new Error('page > count');
        }
        for (var i = 0; i < this.pageDivider && i + index < listings.length; i++) {
            page.listings.push(listings[i + index]);
        }
        return page;
    };
    /**
     * Returns the price minimum of all argument listings.
     * All listings without a price property are set to a price of zero.
     */
    MockPageFilter.prototype.getPriceMinimum = function (listings) {
        var min = 0;
        var minFound = false;
        for (var i = 0; i < listings.length && !minFound; i++) {
            if (listings[i].hasOwnProperty('price')) {
                if (listings[i].price < min) {
                    min = listings[i].price;
                }
            }
            else {
                min = 0;
                minFound = true;
            }
        }
        return min;
    };
    MockPageFilter.prototype.getPriceMaximum = function (listings) {
        var max = 0;
        for (var i = 0; i < listings.length; i++) {
            if (listings[i].hasOwnProperty('price')) {
                if (listings[i].price > max) {
                    max = listings[i].price;
                }
            }
        }
        return max;
    };
    MockPageFilter.prototype.kindOfferFilter = function (element) {
        if (element.type === 'SaleOffer' ||
            element.type === 'ServiceOffer' ||
            element.type === 'RideShareOffer') {
            return true;
        }
        return false;
    };
    MockPageFilter.prototype.kindRequestFilter = function (element) {
        if (element.type === 'BorrowRequest' ||
            element.type === 'PurchaseRequest' ||
            element.type === 'RideShareRequest' ||
            element.type === 'ReoccuringRecreationRequest' ||
            element.type === 'SingleRecreationRequest') {
            return true;
        }
        return false;
    };
    /**
     * Filters the argument listings by the argument locations.
     */
    MockPageFilter.prototype.locationFilter = function (listings, locations) {
        var listingsMatch = [];
        listings.forEach(function (listing) {
            var found = false;
            for (var i = 0; i < locations.length && !found; i++) {
                if (listing.location === locations[i]) {
                    listingsMatch.push(listing);
                }
            }
        });
        return listingsMatch;
    };
    /**
     * Filters the listings by price.
     * A listing meet the criteria if its price is lower or same as the maximum price
     * and if the price is higher or same as the minimum price.
     * Short: min <= price <= max
     */
    MockPageFilter.prototype.priceFilter = function (listings, min, max) {
        var listingsMatch = [];
        listings.forEach(function (listing) {
            if (listing.hasOwnProperty('price')) {
                if (listing.price <= max && listing.price >= min) {
                    listingsMatch.push(listing);
                }
            }
            else if (min <= 0) {
                listingsMatch.push(listing);
            }
        });
        return listingsMatch;
    };
    /**
     * Filtes a listing array after types.
     */
    MockPageFilter.prototype.typeFilter = function (listings, types) {
        var listingsMatch = [];
        listings.forEach(function (listing) {
            var found = false;
            for (var i = 0; i < types.length && !found; i++) {
                if (listing.type === types[i]) {
                    listingsMatch.push(listing);
                    found = true;
                }
            }
        });
        return listingsMatch;
    };
    /**
     * Sorts the array by sort criteria.
     * Criteria must be one of:
     * alphabetical_asc, alphabetical_desc, date_asc, date_desc,
     * location_asc, location_desc, price_asc, price_desc
     */
    MockPageFilter.prototype.sort = function (listings, sortCriteria) {
        if (sortCriteria === 'alphabetical_asc') {
            return listings.sort(function (a, b) {
                return a.title - b.title;
            });
        }
        else if (sortCriteria === 'alphabetical_desc') {
            return listings.sort(function (a, b) {
                return b.title - a.title;
            });
        }
        else if (sortCriteria === 'date_asc') {
            return listings.sort(function (a, b) {
                return a.createDate - b.createDate;
            });
        }
        else if (sortCriteria === 'date_desc') {
            return listings.sort(function (a, b) {
                return b.createDate - a.createDate;
            });
        }
        else if (sortCriteria === 'location_asc') {
            return listings.sort(function (a, b) {
                return a.location - b.location;
            });
        }
        else if (sortCriteria === 'location_desc') {
            return listings.sort(function (a, b) {
                return b.location - a.location;
            });
        }
        else if (sortCriteria === 'price_asc') {
            return listings.sort(function (a, b) {
                if (a.hasOwnProperty('price') && b.hasOwnProperty('price')) {
                    return a.price - b.price;
                }
                else if (a.hasOwnProperty('price') && !b.hasOwnProperty('price')) {
                    return a;
                }
                else if (!a.hasOwnProperty('price') && b.hasOwnProperty('price')) {
                    return -b;
                }
                else if (!a.hasOwnProperty('price') && !b.hasOwnProperty('price')) {
                    return 0;
                }
            });
        }
        else if (sortCriteria === 'price_desc') {
            return listings.sort(function (a, b) {
                if (a.hasOwnProperty('price') && b.hasOwnProperty('price')) {
                    return b.price - a.price;
                }
                else if (a.hasOwnProperty('price') && !b.hasOwnProperty('price')) {
                    return -a;
                }
                else if (!a.hasOwnProperty('price') && b.hasOwnProperty('price')) {
                    return b;
                }
                else if (!a.hasOwnProperty('price') && !b.hasOwnProperty('price')) {
                    return 0;
                }
            });
        }
        else {
            throw new Error('Invalid sort method!');
        }
    };
    return MockPageFilter;
}());
exports.MockPageFilter = MockPageFilter;
//# sourceMappingURL=mock-page.filter.js.map