"use strict";
var http_1 = require("@angular/http");
var Subject_1 = require("rxjs/Subject");
var mock_page_filter_1 = require("./mock-page.filter");
/**
 * This class mocks a listing rest server.
 * Only for testing purpose.
 */
var MockServer = (function () {
    function MockServer() {
        this.activeUser = {
            username: '',
            password: '',
            authenticated: false,
            isAdmin: false
        };
        this.users = [
            [{
                    username: 'akessler',
                    password: '123'
                }, {
                    userID: 1,
                    userImage: '123',
                    firstName: 'Anne',
                    lastName: 'Kessler',
                    isAdmin: false,
                    phone: '12345678910',
                    location: 'mannheim',
                    position: 'godfather',
                    eMail: 'anne.kessler@hallomail.com'
                }],
            [{
                    username: 'mmustermann',
                    password: '123'
                }, {
                    userID: 2,
                    userImage: '456',
                    firstName: 'Marigold',
                    lastName: 'Mustermann',
                    isAdmin: false,
                    phone: '12345678910',
                    location: 'Hamburg',
                    position: 'Lakai',
                    eMail: 'm.mustermann@hallomail.com'
                }]
        ];
        this.listings = [
            {
                type: 'SaleOffer',
                creator: 'mmustermann',
                comments: null,
                createDate: 1495804073888,
                description: 'Ein Sofa',
                expiryDate: 1495804713707,
                id: 1,
                isActive: true,
                location: 'mannheim',
                title: 'Test 1',
                price: 500,
                mainImage: 'assets/images/bit-ka-logo.png',
                imageGallery: ['assets/images/bit-ka-logo.png'],
                condition: 'new'
            }, {
                type: 'ServiceOffer',
                creator: 'mmustermann',
                comments: null,
                createDate: 1495804073888,
                description: 'Ein Sofa',
                expiryDate: 1495804713707,
                id: 1,
                isActive: true,
                location: 'mannheim',
                title: 'Test 500',
                price: 0,
                mainImage: 'assets/images/bit-ka-logo.png',
                imageGallery: ['assets/images/bit-ka-logo.png']
            }, {
                type: 'SaleOffer',
                creator: 'mmustermann',
                comments: null,
                createDate: 1495804073888,
                description: 'Ein Sofa',
                expiryDate: 1495804713707,
                id: 2,
                isActive: true,
                location: 'mannheim',
                title: 'Test 2',
                price: 250,
                mainImage: 'assets/images/bit-ka-logo.png',
                imageGallery: ['assets/images/bit-ka-logo.png'],
                condition: 'used'
            }, {
                type: 'ServiceOffer',
                creator: 'mmustermann',
                comments: null,
                createDate: 1495804073888,
                description: 'Ein Sofa',
                expiryDate: 1495804713707,
                id: 1,
                isActive: true,
                location: 'mannheim',
                title: 'Test 3',
                price: 50000,
                mainImage: 'assets/images/bit-ka-logo.png',
                imageGallery: ['assets/images/bit-ka-logo.png']
            }
        ];
        this.pageFilter = new mock_page_filter_1.MockPageFilter();
    }
    /**
     * Receives the incoming request and proceeds them.
     * @argument {NetworkRequest} networkRequest
     * @return {Observable<Response>}
     */
    MockServer.prototype.process = function (networkRequest) {
        var _this = this;
        var source = new Subject_1.Subject();
        var observable = source.asObservable();
        setTimeout(function () {
            source.next(_this.processRequest(networkRequest));
        }, (Math.random() * 1000));
        return observable;
    };
    /**
     * Processes the incoming request and creates a corresponding response.
     * @argument {NetworkRequest} networkRequest
     */
    MockServer.prototype.processRequest = function (networkRequest) {
        console.log('Mockrequest: ', networkRequest);
        var urlFound = false;
        var responseOptions;
        var paths = networkRequest.getPaths();
        if (paths[0] === 'user') {
            if (paths[1] === 'login') {
                urlFound = true;
                responseOptions = this.login(networkRequest);
            }
            else if (paths[1] === 'logout') {
                urlFound = true;
                responseOptions = this.logout(networkRequest);
            }
        }
        else if (paths[0] === 'listings') {
            if (paths.length < 1) {
                urlFound = true;
                responseOptions = this.getListings(networkRequest);
            }
            else if (paths[1] === 'active') {
                urlFound = true;
                responseOptions = this.getActiveListings(networkRequest);
            }
            else if (paths[1] === 'inactive') {
                urlFound = true;
                responseOptions = this.getInactiveListings(networkRequest);
            }
        }
        else if (paths[0] === 'listing') {
            if (paths[1] === 'create') {
                urlFound = true;
                responseOptions = this.createListing(networkRequest);
            }
            else {
                urlFound = true;
                responseOptions = this.getListing(networkRequest);
            }
        }
        if (!urlFound) {
            responseOptions = this.notFound();
        }
        var response = new http_1.Response(responseOptions);
        console.log('Mockresponse: ', response);
        return response;
    };
    MockServer.prototype.getListing = function (networkRequest) {
        var responseOptions = this.responseOptions();
        var id = networkRequest.getPaths()[1];
        console.log(id, 'id');
        this.listings.forEach(function (listing) {
            console.log(listing.id == id, 'listing');
            if (listing.id == id) {
                console.log('found');
                responseOptions.status = 200;
                responseOptions.body = listing;
                return responseOptions;
            }
        });
        // responseOptions.status = 404;
        return responseOptions;
    };
    // TODO: Research main headers from the actual server.
    /**
     * Creates a new ResponseOptions object with base properties already set.
     */
    MockServer.prototype.responseOptions = function () {
        var responseOptions = new http_1.ResponseOptions();
        return responseOptions;
    };
    /**
     *
     */
    MockServer.prototype.notFound = function () {
        var responseOptions = this.responseOptions();
        responseOptions.status === 404;
        return responseOptions;
    };
    /**
     * Verify the user credentionals.
     */
    MockServer.prototype.login = function (networkRequest) {
        var responseOptions = this.responseOptions();
        var body = networkRequest.getBody();
        if (body.hasOwnProperty('password') && body.hasOwnProperty('username')) {
            var found = false;
            for (var i = 0; i < this.users.length && !found; i++) {
                if (this.users[i][0].username === body.username && this.users[i][0].password === body.password) {
                    responseOptions.body = this.users[i][1];
                    responseOptions.status = 200;
                    this.activeUser.username = body.username;
                    this.activeUser.password = body.password;
                    this.activeUser.authenticated = true;
                    this.activeUser.isAdmin = this.users[i][1].isAdmin;
                    found = true;
                }
            }
            if (!found) {
                responseOptions.status = 401;
            }
        }
        else {
            responseOptions.status = 400;
        }
        return responseOptions;
    };
    /**
     * Discard the authentication of an active user.
     */
    MockServer.prototype.logout = function (networkRequest) {
        var responseOptions = this.responseOptions();
        if (this.activeUser.authenticated) {
            responseOptions.status = 200;
        }
        else {
            responseOptions.status = 401;
        }
        return responseOptions;
    };
    /**
     * Returns a card with the specific listings which match the request queries.
     * This method is private only.
     */
    MockServer.prototype.getListings = function (networkRequest) {
        var responseOptions = this.responseOptions();
        if (this.activeUser.authenticated) {
            if (this.activeUser.isAdmin) {
                responseOptions.status = 200;
                responseOptions.body = this.createPageFromDatabase(networkRequest.getQueries());
            }
            else {
                responseOptions.status === 403;
            }
        }
        else {
            responseOptions.status === 401;
        }
        return responseOptions;
    };
    /**
     *
     */
    MockServer.prototype.createPageFromDatabase = function (queries) {
        var criteria = {};
        queries.forEach(function (query) {
            if (query.key === 'page') {
                criteria.page = parseInt(query.values[0]);
            }
            else if (query.key === 'location') {
                criteria.loaction = query.values;
            }
            else if (query.key === 'price_min') {
                criteria.price_min = parseInt(query.values[0]);
            }
            else if (query.key === 'price_max') {
                criteria.price_max = parseInt(query.values[0]);
            }
            else if (query.key === 'type') {
                criteria.type = query.values;
            }
            else if (query.key === 'sort') {
                criteria.sort = query.values[0];
            }
            else {
                throw new Error('invalid query: ' + query.key);
            }
        });
        return this.pageFilter.createPage(this.listings, criteria);
    };
    MockServer.prototype.getActiveListings = function (networkRequest) {
        console.log(networkRequest.getUrl(), 'onetwothree');
        var responseOptions = this.responseOptions();
        if (this.activeUser.authenticated) {
            responseOptions.status = 200;
            responseOptions.body = this.createPageFromDatabase(networkRequest.getQueries());
        }
        else {
            responseOptions.status = 401;
        }
        return responseOptions;
    };
    MockServer.prototype.getInactiveListings = function (networkRequest) {
        var responseOptions = this.responseOptions();
        if (this.activeUser.authenticated) {
            var body_1 = [];
            this.listings.forEach(function (listing) {
                if (!listing.isActive) {
                    body_1.push(listing);
                }
            });
            responseOptions.body = body_1;
        }
        else {
            responseOptions.status = 401;
        }
        return responseOptions;
    };
    MockServer.prototype.createListing = function (networkRequest) {
        var responseOptions = this.responseOptions();
        if (this.activeUser.authenticated) {
            this.listings.push(networkRequest.getBody());
            var id = this.listings.length;
            responseOptions.body = {
                id: id
            };
            responseOptions.status = 201;
        }
        else {
            responseOptions.status = 401;
        }
        return responseOptions;
    };
    return MockServer;
}());
exports.MockServer = MockServer;
//# sourceMappingURL=mock.server.js.map