"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var message_service_1 = require("./message.service");
var OverlayDirective = (function () {
    function OverlayDirective(elementRef, renderer, messageService) {
        var _this = this;
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.messageService = messageService;
        // this.displayOverlay();
        this.renderer.setStyle(this.elementRef.nativeElement, 'z-index', '1000');
        // this.renderer.setStyle(this.elementRef.nativeElement, 'left', '-100%');
        this.renderer.setStyle(this.elementRef.nativeElement, 'width', '100%');
        this.renderer.setStyle(this.elementRef.nativeElement, 'height', '100%');
        this.renderer.setStyle(this.elementRef.nativeElement, 'position', 'absolute');
        this.renderer.setStyle(this.elementRef.nativeElement, 'background-color', 'rgba(0,0,0,0.75)');
        // this.renderer.setStyle(this.elementRef.nativeElement, 'transition', '2s');
        this.messageService.getObservable().subscribe(function (message) {
            if (message.message.indexOf(_this.selector) >= 0) {
                if (message.message.indexOf('show') >= 0) {
                    _this.displayOverlay();
                }
                else if (message.message.indexOf('hide') >= 0) {
                    _this.hideOverlay();
                }
            }
        });
    }
    OverlayDirective.prototype.closeOverlay = function () {
        this.elementRef.nativeElement.classList.remove('overlay');
        console.log(this.elementRef.nativeElement);
        this.hideOverlay();
    };
    OverlayDirective.prototype.displayOverlay = function () {
        var _this = this;
        this.elementRef.nativeElement.classList.add('overlay');
        console.log(this.elementRef.nativeElement.classList);
        this.renderer.setStyle(this.elementRef.nativeElement, 'display', 'block');
        // angular ignores possible transitions without a delay
        setTimeout(function () {
            _this.renderer.setStyle(_this.elementRef.nativeElement, 'left', '0');
        }, 10);
    };
    OverlayDirective.prototype.hideOverlay = function () {
        this.renderer.setStyle(this.elementRef.nativeElement, 'display', 'none');
        this.renderer.setStyle(this.elementRef.nativeElement, 'left', '-100%');
    };
    OverlayDirective.prototype.ngOnInit = function () {
        // if (
        //   typeof simpleChanges['overlay'] === 'undefined'
        // ) {
        //   throw new Error('Missing input overlay!');
        // }
        // if (
        //   typeof simpleChanges['selector'] === 'undefined'
        // ) {
        //   throw new Error('Missing input selector!');
        // }
        // if (typeof simpleChanges['overlay']['currentValue'] !== 'boolean') {
        //   throw new Error('Overlay input property can only be a boolean, but is ' + typeof simpleChanges['overlay']['currentValue'] + '!');
        // }
        // if (typeof simpleChanges['selector']['currentValue'] !== 'string') {
        //   throw new Error('Selector is needed to detemine when to change overlay states.');
        // }
    };
    OverlayDirective.prototype.ngOnChanges = function (simpleChanges) {
        if (this.overlay) {
            this.displayOverlay();
        }
        else {
            this.hideOverlay();
        }
    };
    return OverlayDirective;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], OverlayDirective.prototype, "overlay", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], OverlayDirective.prototype, "selector", void 0);
OverlayDirective = __decorate([
    core_1.Directive({
        selector: '[overlay]',
        host: {
            '(showOverlay)': 'displayOverlay()',
            '(closeOverlay)': 'closeOverlay()'
        }
    }),
    __metadata("design:paramtypes", [core_1.ElementRef,
        core_1.Renderer2,
        message_service_1.MessageService])
], OverlayDirective);
exports.OverlayDirective = OverlayDirective;
//# sourceMappingURL=overlay.directive.js.map