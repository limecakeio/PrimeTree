import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: [

  ],
  exports: [
    CommonModule
  ],
  imports: [
    CommonModule
  ],
  providers: [

  ]
})
export class DetailViewModule {
  
}
