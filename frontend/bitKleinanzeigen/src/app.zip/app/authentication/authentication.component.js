"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var authentication_controller_1 = require("./authentication.controller");
var user_1 = require("../model/user/user");
var AuthenticationComponent = (function () {
    function AuthenticationComponent(authenticationController, userService, router) {
        this.authenticationController = authenticationController;
        this.userService = userService;
        this.router = router;
        this.user = this.userService.user;
        this.form = new forms_1.FormGroup({});
        this.form.addControl('username', new forms_1.FormControl('username', forms_1.Validators.required));
        this.form.addControl('password', new forms_1.FormControl('password', forms_1.Validators.required));
    }
    /**
     * Authenticates the user with the input credentionals.
     * After receiving the server validation of the credentionals,
     * the user will be forwarded to the listing overview or a message will be displayed.
     */
    AuthenticationComponent.prototype.authenticate = function () {
        var _this = this;
        this.authenticationController.authenticate(this.user).subscribe(function (employee) {
            _this.userService.userInformation = employee;
            _this.userService.authenticated = true;
            _this.router.navigate(['home']);
        }, function (error) {
            console.error(error);
        }, function () {
        });
    };
    return AuthenticationComponent;
}());
AuthenticationComponent = __decorate([
    core_1.Component({
        selector: 'authentication',
        templateUrl: './authentication.component.html',
        styleUrls: ['./authentication.component.css']
    }),
    __metadata("design:paramtypes", [authentication_controller_1.AuthenticationController,
        user_1.UserService,
        router_1.Router])
], AuthenticationComponent);
exports.AuthenticationComponent = AuthenticationComponent;
//# sourceMappingURL=authentication.component.js.map