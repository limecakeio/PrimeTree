import { NgModule } from '@angular/core';
import { RouterModule, Routes, Resolve } from '@angular/router';

import { CanActivateUser } from './can-activate-user.model';
import { AuthenticationComponent } from '../authentication/authentication'
import { ListingOverviewViewportComponent } from '../model/listings/listings';
import { ListingCreateComponent } from '../model/listings/listing/listing-create.component';
import { ListingDetailViewComponent } from '../model/listings/listing/listing-detail-view.component';
import { ListingResolver } from '../model/listings/listing/listing.resolve';

const routes: Routes = [
  // {
  //   path: 'listing/:id',
  //   component: ListingDetailViewComponent,
  //   resolve: {
  //     listing: ListingResolver
  //   },
  //   canActivate: [ CanActivateUser ]
  // },
  // {
  //   path: 'listing/create/:listingType',
  //   component: ListingCreateComponent,
  //   canActivate: [ CanActivateUser ]
  // },
  {
    path: 'home',
    component: ListingOverviewViewportComponent,
    canActivate: [ CanActivateUser ]
  }, {
    path: '',
    component: AuthenticationComponent
  }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ],
  providers: [ CanActivateUser ]
})
export class RoutingModule {

}
