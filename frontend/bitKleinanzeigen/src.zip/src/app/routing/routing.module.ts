import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CanActivateUser } from './can-activate-user.model';
import { AuthenticationComponent } from '../authentication/authentication'
import { ListingOverviewViewportComponent } from '../model/listings/listings';
import { ListingCreateComponent } from '../model/listings/listing/listing-create.component';

const routes: Routes = [
  {
    path: 'listing/create/:listingType',
    component: ListingCreateComponent,
    canActivate: [ CanActivateUser ]
  },
  {
    path: 'home',
    component: ListingOverviewViewportComponent,
    canActivate: [ CanActivateUser ]
  }, {
    path: '',
    component: AuthenticationComponent
  }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ],
  providers: [ CanActivateUser ]
})
export class RoutingModule {

}
