"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var employee_factory_1 = require("../model/user/employee.factory");
var network_1 = require("../network/network");
/**
 * This controller handles all required functionalities for authentication.
 */
var AuthenticationController = (function () {
    function AuthenticationController(networkService) {
        this.networkService = networkService;
        this.employeeFactory = new employee_factory_1.EmployeeFactory();
    }
    /** Authenticates a user with the argument user credentials from a User object.
     * @argument {User} user includes the user credentials
     * @returns {Observable<Employee>} An Observable which returns an Employee if the right user credentials are send or an error if they are wrong
     */
    AuthenticationController.prototype.authenticate = function (user) {
        var _this = this;
        var request = this.networkService.networkRequest();
        request
            .setHttpMethod(network_1.RequestMethod.Post)
            .addPath('user')
            .addPath('login')
            .setBody(user);
        return this.networkService.send(request).map(function (response) {
            if (response.status === 200) {
                return _this.employeeFactory.createEmployee(response.json());
            }
            throw new Error('Some or all user credentials are wrong!');
        });
    };
    /** Discards the authentication of the active user.
     * @return {Observable<void>} An Observable which returns successfully if the user credentials are invoked or throws an error if the user was not authenticated beforhand.
     */
    AuthenticationController.prototype.logout = function () {
        var request = this.networkService.networkRequest();
        request
            .setHttpMethod(network_1.RequestMethod.Post)
            .addPath('user')
            .addPath('logout');
        return this.networkService.send(request).map(function (response) {
            if (response.status === 200) {
                return;
            }
            throw new Error('A user must be authenticated to use this method!');
        });
    };
    return AuthenticationController;
}());
AuthenticationController = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [network_1.NetworkService])
], AuthenticationController);
exports.AuthenticationController = AuthenticationController;
//# sourceMappingURL=authentication.controller.js.map