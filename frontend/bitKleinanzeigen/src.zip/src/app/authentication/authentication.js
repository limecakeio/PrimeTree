"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require("./authentication.module"));
__export(require("./authentication.component"));
__export(require("./authentication.controller"));
//# sourceMappingURL=authentication.js.map