import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { RequestMethod, Response } from '@angular/http';
import 'rxjs/add/operator/map';

import { NetworkService } from '../../network/network.service';
import { NetworkRequest } from '../../network/network.request';

import { UserMin, UserMinFactory } from './user-min.model';

@Injectable()
export class UserController {

}
