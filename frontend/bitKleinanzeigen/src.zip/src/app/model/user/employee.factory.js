"use strict";
var employee_model_1 = require("./employee.model");
var EmployeeFactory = (function () {
    function EmployeeFactory() {
        this.employeeProperties = [
            'userID', 'userImage', 'firstName',
            'lastName', 'isAdmin', 'phone',
            'location', 'position', 'eMail'
        ];
    }
    EmployeeFactory.prototype.checkProperties = function (body) {
        this.employeeProperties.forEach(function (employeeProperty) {
            if (!body.hasOwnProperty(employeeProperty)) {
                return false;
            }
        });
        return true;
    };
    EmployeeFactory.prototype.findMissingProperties = function (body) {
        var missingProperties = [];
        this.employeeProperties.forEach(function (employeeProperty) {
            if (!body.hasOwnProperty(employeeProperty)) {
                missingProperties.push(employeeProperty);
            }
        });
        return missingProperties;
    };
    /**
     * Creates a new employee from body object.
     * Throws an error if some or all properties are missing.
     */
    EmployeeFactory.prototype.createEmployee = function (body) {
        if (this.checkProperties(body)) {
            var employee_1 = new employee_model_1.Employee();
            this.employeeProperties.forEach(function (employeeProperty) {
                employee_1[employeeProperty] = body[employeeProperty];
            });
            return employee_1;
        }
        throw new Error('Not possible to create an employee, ' + this.findMissingProperties(body).join(', ') + '.');
    };
    return EmployeeFactory;
}());
exports.EmployeeFactory = EmployeeFactory;
//# sourceMappingURL=employee.factory.js.map