"use strict";
var UserMin = (function () {
    function UserMin() {
    }
    return UserMin;
}());
exports.UserMin = UserMin;
var UserMinFactory = (function () {
    function UserMinFactory() {
        this.userMinProperties = [
            'userId', 'userImage', 'firstName', 'lastName', 'isAdmin', 'eMail'
        ];
    }
    UserMinFactory.prototype.createUserMin = function (body) {
        if (this.checkProperties(body)) {
            var userMin = new UserMin();
            this.assignProperties(userMin, body);
            return userMin;
        }
        else {
            throw new Error('Cannot create UserMin: ' + this.findMissingProperties(body).join(', ') + ' are missing.');
        }
    };
    UserMinFactory.prototype.checkProperties = function (body) {
        this.userMinProperties.forEach(function (property) {
            if (!body.hasOwnProperty(property)) {
                return false;
            }
        });
        return true;
    };
    UserMinFactory.prototype.assignProperties = function (userMin, body) {
        this.userMinProperties.forEach(function (property) {
            userMin[property] = body[property];
        });
    };
    UserMinFactory.prototype.findMissingProperties = function (body) {
        var missingProperies = [];
        this.userMinProperties.forEach(function (property) {
            if (!body.hasOwnProperty(property)) {
                missingProperies.push(property);
            }
        });
        return missingProperies;
    };
    return UserMinFactory;
}());
exports.UserMinFactory = UserMinFactory;
//# sourceMappingURL=user-min.model.js.map