"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var sale_offer_model_1 = require("./sale-offer.model");
var listing_factory_1 = require("../../listing/listing.factory");
var SaleOfferFactory = (function (_super) {
    __extends(SaleOfferFactory, _super);
    function SaleOfferFactory() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.vitalProperties = ['price', 'condition'];
        return _this;
    }
    /**
     * checks if all neccesarily properties are set to convert the param object into a saleoffer object
     * @param {any} body an object which holds the properties
     * @return {boolean} indicates wheter the body has all properties
     */
    SaleOfferFactory.prototype.checkProperties = function (body) {
        if (_super.prototype.checkProperties.call(this, body)) {
            for (var i = 0; i < this.vitalProperties.length; i++) {
                if (!body.hasOwnProperty(this.vitalProperties[i])) {
                    return false;
                }
            }
            return true;
        }
        console.log(body, _super.prototype.checkProperties.call(this, body));
        return false;
    };
    SaleOfferFactory.prototype.findMissingProperties = function (body) {
        var missingProperties = _super.prototype.findMissingProperties.call(this, body);
        this.vitalProperties.forEach(function (property) {
            missingProperties.push(property);
        });
        return missingProperties;
    };
    /**
     * creates a saleoffer based on the properties from the param object
     * @param {any} body an instance of object which holds all properties
     * @return {SaleOffer} a new instance of SaleOffer with all properties set accordingly to the body object
     * @throws {Error} an error if some properties are missing
     */
    SaleOfferFactory.prototype.createListing = function (body) {
        if (this.checkProperties(body)) {
            var listing = new sale_offer_model_1.SaleOffer();
            this.assignProperties(listing, body);
            return listing;
        }
        else {
            throw new Error('Cannot create SaleOffer from body: ' + this.findMissingProperties(body).join(', ') + ' are missing.');
        }
    };
    /**
     * Assigns all properties for a SaleOffer from body to listing.
     */
    SaleOfferFactory.prototype.assignProperties = function (listing, body) {
        _super.prototype.assignProperties.call(this, listing, body);
        this.vitalProperties.forEach(function (property) {
            listing[property] = body[property];
        });
        if (body.hasOwnProperty('mainImage')) {
            listing.mainImage = body.mainImage;
        }
        if (body.hasOwnProperty('imageGallery')) {
            listing.imageGallery = body.imageGallery;
        }
    };
    return SaleOfferFactory;
}(listing_factory_1.ListingFactory));
exports.SaleOfferFactory = SaleOfferFactory;
//# sourceMappingURL=sale-offer.factory.js.map