"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var sale_offer_model_1 = require("./sale-offer.model");
var platform_browser_1 = require("@angular/platform-browser");
var listing_controller_1 = require("../../network/listing.controller");
var user_1 = require("../../../user/user");
var listing_reposetory_1 = require("../../listing.reposetory");
var SaleOfferComponent = (function () {
    function SaleOfferComponent(listingController, listingReposetory, userService, domSanitizer) {
        this.listingController = listingController;
        this.listingReposetory = listingReposetory;
        this.userService = userService;
        this.domSanitizer = domSanitizer;
        this.isOwner = false;
    }
    SaleOfferComponent.prototype.remove = function () {
        var _this = this;
        this.listingController.removeListing(this.listing.id).subscribe(function (removed) {
            _this.listingReposetory.update();
        }, function (error) {
            console.log('Remove', error.message);
        }, function () {
        });
    };
    SaleOfferComponent.prototype.ngOnInit = function () {
    };
    return SaleOfferComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", sale_offer_model_1.SaleOffer)
], SaleOfferComponent.prototype, "listing", void 0);
SaleOfferComponent = __decorate([
    core_1.Component({
        selector: 'saleoffer',
        templateUrl: './sale-offer.component.html'
    }),
    __metadata("design:paramtypes", [listing_controller_1.ListingController,
        listing_reposetory_1.ListingReposetory,
        user_1.UserService,
        platform_browser_1.DomSanitizer])
], SaleOfferComponent);
exports.SaleOfferComponent = SaleOfferComponent;
//# sourceMappingURL=sale-offer.component.js.map