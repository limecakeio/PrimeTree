"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var listing_descriptor_1 = require("../../listing/listing.descriptor");
var service_offer_preview_component_1 = require("./service-offer-preview.component");
var service_offer_create_form_component_1 = require("./service-offer-create-form.component");
var service_offer_factory_1 = require("./service-offer.factory");
var ServiceOfferDescriptor = (function (_super) {
    __extends(ServiceOfferDescriptor, _super);
    function ServiceOfferDescriptor() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ServiceOfferDescriptor.prototype.listingPreviewComponentType = function () {
        return service_offer_preview_component_1.ServiceOfferPreviewComponent;
    };
    ServiceOfferDescriptor.prototype.listingType = function () {
        return 'ServiceOffer';
    };
    ServiceOfferDescriptor.prototype.listingCreateForm = function () {
        return service_offer_create_form_component_1.ServiceOfferCreateFormComponent;
    };
    ServiceOfferDescriptor.prototype.listingFactory = function () {
        return new service_offer_factory_1.ServiceOfferFactory('ServiceOffer');
    };
    return ServiceOfferDescriptor;
}(listing_descriptor_1.ListingDescriptor));
exports.ServiceOfferDescriptor = ServiceOfferDescriptor;
//# sourceMappingURL=service-offer.descriptor.js.map