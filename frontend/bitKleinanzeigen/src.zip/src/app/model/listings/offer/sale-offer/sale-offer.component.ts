import { Component, Input, OnInit } from '@angular/core';
import { SaleOffer } from './sale-offer.model';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';

import { ListingController } from '../../network/listing.controller';
import { UserService } from '../../../user/user';
import { ListingReposetory } from '../../listing.reposetory';

@Component({
  selector: 'saleoffer',
  templateUrl: './sale-offer.component.html'
})
export class SaleOfferComponent implements OnInit {

  @Input() listing : SaleOffer;

  isOwner : boolean = false;
  image : SafeStyle;

  constructor(
    private listingController : ListingController,
    private listingReposetory : ListingReposetory,
    private userService : UserService,
    private domSanitizer : DomSanitizer
  ) {

  }

  remove() : void {
    this.listingController.removeListing(this.listing.id).subscribe((removed : boolean) => {
      this.listingReposetory.update();
    }, (error : Error) => {
      console.log('Remove', error.message);
    }, () => {

    });
  }

  ngOnInit() {

  }
}
