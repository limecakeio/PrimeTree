import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SaleOfferComponent } from './sale-offer.component';
import { SaleOfferPreviewComponent } from './sale-offer-preview.component';
import { SaleOfferCreateFormComponent } from './sale-offer-create.component';

import { FormModule } from '../../../../form/form.module';

@NgModule({
  declarations: [
    SaleOfferComponent,
    SaleOfferPreviewComponent,
    SaleOfferCreateFormComponent
  ],
  exports: [
    SaleOfferComponent,
    SaleOfferPreviewComponent,
    SaleOfferCreateFormComponent
  ],
  imports: [
    CommonModule,
    FormModule
  ],
  providers: [

  ]
})
export class SaleOfferModule {

}
