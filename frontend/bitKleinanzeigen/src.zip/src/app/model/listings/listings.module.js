"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var forms_1 = require("@angular/forms");
var listing_module_1 = require("./listing/listing.module");
var listing_overview_viewport_component_1 = require("./listing-overview-viewport.component");
var sale_offer_1 = require("./offer/sale-offer/sale-offer");
var listing_preview_component_1 = require("./listing/listing-preview.component");
var listing_create_form_component_1 = require("./listing/listing-create-form.component");
var listing_descriptor_1 = require("./listing/listing.descriptor");
var sale_offer_descriptor_1 = require("./offer/sale-offer/sale-offer.descriptor");
var service_offer_descriptor_1 = require("./offer/service-offer/service-offer.descriptor");
var service_offer_module_1 = require("./offer/service-offer/service-offer.module");
var form_module_1 = require("../../form/form.module");
var ListingsModule = (function () {
    function ListingsModule() {
    }
    return ListingsModule;
}());
ListingsModule = __decorate([
    core_1.NgModule({
        declarations: [
            listing_overview_viewport_component_1.ListingOverviewViewportComponent,
            listing_preview_component_1.ListingPreviewComponent,
            listing_create_form_component_1.ListingCreateFormComponent
        ],
        exports: [
            listing_module_1.ListingModule,
            listing_overview_viewport_component_1.ListingOverviewViewportComponent,
            sale_offer_1.SaleOfferModule,
            service_offer_module_1.ServiceOfferModule
        ],
        imports: [
            forms_1.FormsModule,
            forms_1.ReactiveFormsModule,
            common_1.CommonModule,
            sale_offer_1.SaleOfferModule,
            service_offer_module_1.ServiceOfferModule,
            form_module_1.FormModule,
            listing_module_1.ListingModule.withDescriptors([
                listing_descriptor_1.ListingDescriptor,
                sale_offer_descriptor_1.SaleOfferDescriptor,
                service_offer_descriptor_1.ServiceOfferDescriptor
            ])
        ],
        providers: []
    })
], ListingsModule);
exports.ListingsModule = ListingsModule;
//# sourceMappingURL=listings.module.js.map