import { Offering } from '../listing.model';

export class SellItem extends Offering {
  // public condition : string = '';
  // public images : string[] = [];
  public price : number;
}
