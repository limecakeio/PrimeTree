// import { Injectable } from '@angular/core';
// import { FormGroup } from '@angular/forms';
// import { ListingController } from '../../network/listing.controller';
// import { ListingReposetory } from '../../listing.reposetory';
// import { Router } from '@angular/router';
// import { SecurityModel } from '../../../../security/security.model';
//
// @Injectable()
// export abstract class ListingCreateForm {
//
//   form : FormGroup = new FormGroup({});
//   model : any = {};
//
//   constructor(private listingType : string,
//     private listingController : ListingController,
//     private repo : ListingReposetory,
//     private router : Router,
//     private securityModel : SecurityModel) {
//
//   }
//
//   submit() {
//     if (this.form.valid) {
//       // this.listingController.postListing()
//     }
//   }
//
// }
//# sourceMappingURL=listingCreateForm.model.js.map