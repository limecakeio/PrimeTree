"use strict";
var Location;
(function (Location) {
    Location[Location["HD"] = 0] = "HD";
    Location[Location["MA"] = 1] = "MA";
})(Location = exports.Location || (exports.Location = {}));
var Offering = (function () {
    function Offering() {
    }
    return Offering;
}());
exports.Offering = Offering;
//# sourceMappingURL=listing.model.js.map