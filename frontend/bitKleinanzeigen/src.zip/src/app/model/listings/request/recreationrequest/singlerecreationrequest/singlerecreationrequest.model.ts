import { RecreationRequest } from '../recreationrequest.model';

export class SingleRecreationRequest {
  dateAndTime : Date;
}
