import { Type } from '@angular/core';

import { ListingPreviewComponent } from './listing-preview.component';
import { ListingCreateFormComponent } from './listing-create-form.component';
import { ListingFactory } from './listing.factory';

/**
 *
 */
export class ListingDescriptor {

  public listingPreviewComponentType() : Type<ListingPreviewComponent> {
    return ListingPreviewComponent;
  }

  public listingType() : string {
    return 'Listing';
  };

  public listingCreateForm() : Type<ListingCreateFormComponent> {
    return ListingCreateFormComponent;
  }

  public listingFactory() : ListingFactory {
    return new ListingFactory('Listing');
  }

}
