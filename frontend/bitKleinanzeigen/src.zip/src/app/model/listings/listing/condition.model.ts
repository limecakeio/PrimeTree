export enum Condition {
  NEW, USED
}
