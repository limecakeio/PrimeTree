"use strict";
var listing_model_1 = require("./listing.model");
/**
 * ListingFactory
 */
var ListingFactory = (function () {
    function ListingFactory(type) {
        this.type = '';
        this.vitalListingProperties = [
            'comments', 'createDate', 'creator', 'description', 'expiryDate', 'id',
            'isActive', 'location', 'title', 'type'
        ];
        this.type = type;
    }
    ListingFactory.prototype.findMissingProperties = function (body) {
        var missingProperties = [];
        this.vitalListingProperties.forEach(function (property) {
            if (!body.hasOwnProperty(property)) {
                missingProperties.push(property);
            }
        });
        return missingProperties;
    };
    /**
     * creates a new listing from the param body
     * @param {object} body an object with the needed properties
     * @return {Listing}
     */
    ListingFactory.prototype.createListing = function (body) {
        if (this.checkProperties(body)) {
            var listing = new listing_model_1.Listing();
            this.assignProperties(listing, body);
            return listing;
        }
        else {
            throw new Error('Cannot create Listing from body: ' + this.findMissingProperties(body).join() + ' are missing');
        }
    };
    /**
     * verify if the param object has all necessarily properties to build a Listing object
     * @param {any} body the object which properties should be examined
     * @return {boolean} Returns true if all needed properties are set, otherwise false
     */
    ListingFactory.prototype.checkProperties = function (body) {
        if (body === null || typeof body === 'undefined' || typeof body !== 'object') {
            return false;
        }
        this.vitalListingProperties.forEach(function (property) {
            if (!body.hasOwnProperty(property)) {
                return false;
            }
        });
        return true;
    };
    /**
     * Assigns all listings properties from body to listing.
     */
    ListingFactory.prototype.assignProperties = function (listing, body) {
        this.vitalListingProperties.forEach(function (property) {
            listing[property] = body[property];
        });
    };
    return ListingFactory;
}());
exports.ListingFactory = ListingFactory;
//# sourceMappingURL=listing.factory.js.map