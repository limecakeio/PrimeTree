"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
/**
 * This class prevent the use of an output to create a cummunication canal
 * between the ListingCreateComponent, which is a placeholder for listing forms
 * and does the preserving of the listing and the actual forms.
 */
var ListingCreateService = (function () {
    function ListingCreateService() {
    }
    return ListingCreateService;
}());
ListingCreateService = __decorate([
    core_1.Injectable()
], ListingCreateService);
exports.ListingCreateService = ListingCreateService;
//# sourceMappingURL=listing-create.service.js.map