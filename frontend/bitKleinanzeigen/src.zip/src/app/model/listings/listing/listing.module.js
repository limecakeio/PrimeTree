"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var listing_component_1 = require("./listing.component");
var listing_creator_1 = require("./listing.creator");
var listing_controller_1 = require("./listing.controller");
var listing_repository_1 = require("./listing.repository");
var listing_preview_placeholder_component_1 = require("./listing-preview-placeholder.component");
var listing_create_component_1 = require("./listing-create.component");
var listing_create_form_placeholder_component_1 = require("./listing-create-form-placeholder.component");
var listing_descriptor_handler_1 = require("./listing-descriptor.handler");
var ListingModule = ListingModule_1 = (function () {
    function ListingModule() {
    }
    // public static withComponents(components: any[]) {
    //       return {
    //           ngModule: ListingModule,
    //           providers: [
    //               {provide: ANALYZE_FOR_ENTRY_COMPONENTS, useValue: components, multi: true}
    //           ]
    //       }
    //   }
    ListingModule.withDescriptors = function (listingDescriptors) {
        // listingDescriptors.forEach((listingDescriptor : typeof ListingDescriptor) => {
        //   ListingModule.listingDescriptors.push(new listingDescriptor());
        // });
        // let previewComponents : any[] = [];
        // ListingModule.listingDescriptors.forEach((listingDescriptor : ListingDescriptor) => {
        //   previewComponents.push(listingDescriptor.listingPreviewComponentType());
        //   previewComponents.push(listingDescriptor.listingCreateForm());
        // });
        listingDescriptors.forEach(function (listingDescriptortypeof) {
            ListingModule_1.listingDescriptorHandler.addListingDescriptorTypeof(listingDescriptortypeof);
        });
        var componentTypes = [].concat(ListingModule_1.listingDescriptorHandler.getAllListingCreateFormComponentTypes(), ListingModule_1.listingDescriptorHandler.getAllListingPreviewComponentTypes());
        return {
            ngModule: ListingModule_1,
            providers: [
                {
                    provide: core_1.ANALYZE_FOR_ENTRY_COMPONENTS,
                    useValue: componentTypes,
                    multi: true
                }
            ]
        };
    };
    return ListingModule;
}());
ListingModule.listingDescriptors = [];
ListingModule.listingDescriptorHandler = new listing_descriptor_handler_1.ListingDescriptorHandler();
ListingModule = ListingModule_1 = __decorate([
    core_1.NgModule({
        declarations: [
            listing_component_1.ListingComponent,
            listing_preview_placeholder_component_1.ListingPreviewPlaceholderComponent,
            listing_create_form_placeholder_component_1.ListingCreateFormPlaceholderComponent,
            listing_create_component_1.ListingCreateComponent
        ],
        exports: [
            listing_component_1.ListingComponent,
            listing_preview_placeholder_component_1.ListingPreviewPlaceholderComponent,
            listing_create_form_placeholder_component_1.ListingCreateFormPlaceholderComponent,
            listing_create_component_1.ListingCreateComponent
        ],
        providers: [
            listing_creator_1.ListingCreator,
            listing_controller_1.ListingController,
            listing_repository_1.ListingRepository
        ],
    })
], ListingModule);
exports.ListingModule = ListingModule;
var ListingModule_1;
//# sourceMappingURL=listing.module.js.map