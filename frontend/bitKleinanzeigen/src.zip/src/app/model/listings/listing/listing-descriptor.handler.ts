import { Type } from '@angular/core';

import { ListingDescriptor } from './listing.descriptor';
import { ListingFactory } from './listing.factory';
import { ListingPreviewComponent } from './listing-preview.component';
import { ListingComponent } from './listing.component';
import { ListingCreateFormComponent } from './listing-create-form.component';

export class ListingDescriptorHandler {

  private listingsDescriptors : ListingDescriptor[] = [];

  private nullListingDesriptor : ListingDescriptor = new ListingDescriptor();

  public addListingDescriptor(listingsDescriptor : ListingDescriptor) : void {
    this.listingsDescriptors.push(listingsDescriptor);
  }

  public addListingDescriptorTypeof(listingsDescriptorTypeoff : typeof ListingDescriptor) : void {
    this.addListingDescriptor(new listingsDescriptorTypeoff());
  }

  public findListingFactoryFromListingType(listingType : string) : ListingFactory {
    return this.findListingDescriptorFromListingType(listingType).listingFactory();
  }

  public findListingPreviewComponentTypeFromListingType(listingType : string) : Type<ListingPreviewComponent> {
    return this.findListingDescriptorFromListingType(listingType).listingPreviewComponentType();
  }

  public findListingCreateFormComponentTypeFromLisitingType(listingType : string) : Type<ListingCreateFormComponent> {
    return this.findListingDescriptorFromListingType(listingType).listingCreateForm();
  }

  public findListingComponentTypeFromListingType(listingType : string) : Type<ListingComponent> {
    throw new Error('not yet implemented!');
  }

  /**
   * Returns a ListingDescriptor which type matches the agument listing type.
   * Returns the base lisiting descriptor if no matching descriptor is found.
   */
  private findListingDescriptorFromListingType(listingType : string) : ListingDescriptor {
    for (let i = 0; i < this.listingsDescriptors.length; i++) {
      if (this.listingsDescriptors[i].listingType() === listingType) {
        return this.listingsDescriptors[i];
      }
    }
    console.error('No matching listing descriptor found for: ' + listingType + '. Please add one in LisitingModule.')
    return this.nullListingDesriptor;
  }

  public getAllListingPreviewComponentTypes() : Type<ListingPreviewComponent>[] {
    let listingPreviewComponentTypes : Type<ListingPreviewComponent>[] = [];
    this.listingsDescriptors.forEach((listingsDescriptor : ListingDescriptor) => {
      listingPreviewComponentTypes.push(listingsDescriptor.listingPreviewComponentType());
    });
    return listingPreviewComponentTypes;
  }

  public getAllListingComponentTypes() : Type<ListingComponent>[] {
    let listingComponentTypes : Type<ListingComponent>[] = [];
    this.listingsDescriptors.forEach((listingsDescriptor : ListingDescriptor) => {
      // TODO: Make the magic happen!
    });
    return listingComponentTypes;
  }

  public getAllListingCreateFormComponentTypes() : Type<ListingCreateFormComponent>[] {
    let listingCreateFormComponentType : Type<ListingCreateFormComponent>[] = [];
    this.listingsDescriptors.forEach((listingsDescriptor : ListingDescriptor) => {
      listingCreateFormComponentType.push(listingsDescriptor.listingCreateForm());
    });
    return listingCreateFormComponentType;
  }

}
