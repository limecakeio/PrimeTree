import {
  NgModule,
  ANALYZE_FOR_ENTRY_COMPONENTS,
  Type
} from '@angular/core';


import { ListingComponent } from './listing.component';
import { ListingPreviewComponent } from './listing-preview.component';
import { ListingCreator } from './listing.creator';

import { ListingController } from './listing.controller';
import { ListingRepository } from './listing.repository';
import { ListingPreviewPlaceholderComponent } from './listing-preview-placeholder.component';
import { ListingDescriptor } from './listing.descriptor';
import { ListingCreateComponent } from './listing-create.component';
import { ListingCreateFormPlaceholderComponent } from './listing-create-form-placeholder.component';

import { ListingDescriptorHandler } from './listing-descriptor.handler';

@NgModule({
  declarations: [
    ListingComponent,
    ListingPreviewPlaceholderComponent,
    ListingCreateFormPlaceholderComponent,
    ListingCreateComponent
  ],
  exports: [
    ListingComponent,
    ListingPreviewPlaceholderComponent,
    ListingCreateFormPlaceholderComponent,
    ListingCreateComponent
  ],
  providers: [
    ListingCreator,
    ListingController,
    ListingRepository
  ],
})
export class ListingModule {

  public static listingDescriptors : ListingDescriptor[] = [];

  public static listingDescriptorHandler : ListingDescriptorHandler = new ListingDescriptorHandler();
  // public static withComponents(components: any[]) {
  //       return {
  //           ngModule: ListingModule,
  //           providers: [
  //               {provide: ANALYZE_FOR_ENTRY_COMPONENTS, useValue: components, multi: true}
  //           ]
  //       }
  //   }

    static withDescriptors(listingDescriptors : typeof ListingDescriptor[]) {
      // listingDescriptors.forEach((listingDescriptor : typeof ListingDescriptor) => {
      //   ListingModule.listingDescriptors.push(new listingDescriptor());
      // });
      // let previewComponents : any[] = [];
      // ListingModule.listingDescriptors.forEach((listingDescriptor : ListingDescriptor) => {
      //   previewComponents.push(listingDescriptor.listingPreviewComponentType());
      //   previewComponents.push(listingDescriptor.listingCreateForm());
      // });
      listingDescriptors.forEach((listingDescriptortypeof : typeof ListingDescriptor) => {
        ListingModule.listingDescriptorHandler.addListingDescriptorTypeof(listingDescriptortypeof);
      });

      let componentTypes : Type<any>[] = [].concat(
        ListingModule.listingDescriptorHandler.getAllListingCreateFormComponentTypes(),
        ListingModule.listingDescriptorHandler.getAllListingPreviewComponentTypes()
      );



      return {
          ngModule: ListingModule,
          providers: [
              {
                provide: ANALYZE_FOR_ENTRY_COMPONENTS,
                useValue: componentTypes,
                multi: true
              }
          ]
      }
    }
}
