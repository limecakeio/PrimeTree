"use strict";
var listing_descriptor_1 = require("./listing.descriptor");
var ListingDescriptorHandler = (function () {
    function ListingDescriptorHandler() {
        this.listingsDescriptors = [];
        this.nullListingDesriptor = new listing_descriptor_1.ListingDescriptor();
    }
    ListingDescriptorHandler.prototype.addListingDescriptor = function (listingsDescriptor) {
        this.listingsDescriptors.push(listingsDescriptor);
    };
    ListingDescriptorHandler.prototype.addListingDescriptorTypeof = function (listingsDescriptorTypeoff) {
        this.addListingDescriptor(new listingsDescriptorTypeoff());
    };
    ListingDescriptorHandler.prototype.findListingFactoryFromListingType = function (listingType) {
        return this.findListingDescriptorFromListingType(listingType).listingFactory();
    };
    ListingDescriptorHandler.prototype.findListingPreviewComponentTypeFromListingType = function (listingType) {
        return this.findListingDescriptorFromListingType(listingType).listingPreviewComponentType();
    };
    ListingDescriptorHandler.prototype.findListingCreateFormComponentTypeFromLisitingType = function (listingType) {
        return this.findListingDescriptorFromListingType(listingType).listingCreateForm();
    };
    ListingDescriptorHandler.prototype.findListingComponentTypeFromListingType = function (listingType) {
        throw new Error('not yet implemented!');
    };
    /**
     * Returns a ListingDescriptor which type matches the agument listing type.
     * Returns the base lisiting descriptor if no matching descriptor is found.
     */
    ListingDescriptorHandler.prototype.findListingDescriptorFromListingType = function (listingType) {
        for (var i = 0; i < this.listingsDescriptors.length; i++) {
            if (this.listingsDescriptors[i].listingType() === listingType) {
                return this.listingsDescriptors[i];
            }
        }
        console.error('No matching listing descriptor found for: ' + listingType + '. Please add one in LisitingModule.');
        return this.nullListingDesriptor;
    };
    ListingDescriptorHandler.prototype.getAllListingPreviewComponentTypes = function () {
        var listingPreviewComponentTypes = [];
        this.listingsDescriptors.forEach(function (listingsDescriptor) {
            listingPreviewComponentTypes.push(listingsDescriptor.listingPreviewComponentType());
        });
        return listingPreviewComponentTypes;
    };
    ListingDescriptorHandler.prototype.getAllListingComponentTypes = function () {
        var listingComponentTypes = [];
        this.listingsDescriptors.forEach(function (listingsDescriptor) {
            // TODO: Make the magic happen!
        });
        return listingComponentTypes;
    };
    ListingDescriptorHandler.prototype.getAllListingCreateFormComponentTypes = function () {
        var listingCreateFormComponentType = [];
        this.listingsDescriptors.forEach(function (listingsDescriptor) {
            listingCreateFormComponentType.push(listingsDescriptor.listingCreateForm());
        });
        return listingCreateFormComponentType;
    };
    return ListingDescriptorHandler;
}());
exports.ListingDescriptorHandler = ListingDescriptorHandler;
//# sourceMappingURL=listing-descriptor.handler.js.map