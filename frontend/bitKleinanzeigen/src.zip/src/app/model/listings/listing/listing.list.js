"use strict";
var ListingList = (function () {
    function ListingList() {
    }
    return ListingList;
}());
exports.ListingList = ListingList;
var ListingListFactory = (function () {
    function ListingListFactory() {
        this.listingListProperties = [
            'price_min', 'price_max', 'listings', 'count'
        ];
    }
    ListingListFactory.prototype.createListingList = function (body) {
        if (this.checkProperties(body)) {
            var listingList = new ListingList();
            this.assignProperties(listingList, body);
            return listingList;
        }
        throw new Error('Cannot create a ListingList:' + this.findMissingProperties(body).join(', ') + ' are missing!');
    };
    ListingListFactory.prototype.checkProperties = function (body) {
        this.listingListProperties.forEach(function (property) {
            if (!body.hasOwnProperty(property)) {
                return false;
            }
        });
        return true;
    };
    ListingListFactory.prototype.findMissingProperties = function (body) {
        var missingProperties = [];
        this.listingListProperties.forEach(function (property) {
            if (!body.hasOwnProperty(property)) {
                missingProperties.push(property);
            }
        });
        return missingProperties;
    };
    ListingListFactory.prototype.assignProperties = function (listingList, body) {
        this.listingListProperties.forEach(function (property) {
            listingList[property] = body[property];
        });
    };
    return ListingListFactory;
}());
exports.ListingListFactory = ListingListFactory;
//# sourceMappingURL=listing.list.js.map