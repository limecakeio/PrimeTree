"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var listing_model_1 = require("./listing.model");
var ListingCreateFormPlaceholderComponent = (function () {
    function ListingCreateFormPlaceholderComponent(viewContainerRef, componentFactoryResolver) {
        this.viewContainerRef = viewContainerRef;
        this.componentFactoryResolver = componentFactoryResolver;
        this.called = false;
        this.listingcreated = new core_1.EventEmitter();
        this.updateRepository = new core_1.EventEmitter();
    }
    ListingCreateFormPlaceholderComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log(this.userLocation, 'userLocation');
        if (!this.called) {
            this.called = true;
        }
        else {
            return;
        }
        var componentFactory = this.componentFactoryResolver.resolveComponentFactory(this.listingFormType);
        var componentRef = this.viewContainerRef.createComponent(componentFactory);
        // (<ListingCreateFormComponent>componentRef.instance).model = this.listing;
        componentRef.instance.userLocation = this.userLocation;
        // Output events in dynamic components are currently not supported.
        // @reference https://stackoverflow.com/questions/37683099/output-parameter-in-dynamic-components
        componentRef.instance.listingFormCreateFinished.subscribe(function (listingFormEventModel) {
            _this.listingcreated.emit(listingFormEventModel);
        }, function (error) {
            console.error(error);
        }, function () {
        });
        componentRef.instance.listingFormUpdateRepositoryOutput.subscribe(function () {
            _this.updateRepository.emit();
        }, function (error) {
            console.error(error);
        }, function () {
        });
    };
    return ListingCreateFormPlaceholderComponent;
}());
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], ListingCreateFormPlaceholderComponent.prototype, "listingcreated", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], ListingCreateFormPlaceholderComponent.prototype, "updateRepository", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.Type)
], ListingCreateFormPlaceholderComponent.prototype, "listingFormType", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", listing_model_1.Listing)
], ListingCreateFormPlaceholderComponent.prototype, "listing", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], ListingCreateFormPlaceholderComponent.prototype, "userLocation", void 0);
ListingCreateFormPlaceholderComponent = __decorate([
    core_1.Component({
        selector: 'listing-create-form-placeholder',
        template: ''
    }),
    __metadata("design:paramtypes", [core_1.ViewContainerRef,
        core_1.ComponentFactoryResolver])
], ListingCreateFormPlaceholderComponent);
exports.ListingCreateFormPlaceholderComponent = ListingCreateFormPlaceholderComponent;
//# sourceMappingURL=listing-create-form-placeholder.component.js.map