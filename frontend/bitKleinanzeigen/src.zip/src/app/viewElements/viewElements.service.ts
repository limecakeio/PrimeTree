import { Injectable } from '@angular/core';

@Injectable()
export class ViewElementsService {
  model : any;
}
